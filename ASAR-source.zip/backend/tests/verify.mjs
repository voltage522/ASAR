import { PGlite } from '@electric-sql/pglite';
import { readFileSync } from 'node:fs';
const db = new PGlite();
try {
  // Only Auth identity is stubbed. Tables, SQL functions, roles, RLS and constraints run in PostgreSQL.
  await db.exec(`
    create role anon; create role authenticated;
    create schema auth;
    create table auth.users(id uuid primary key, email_confirmed_at timestamptz);
    create function auth.uid() returns uuid language sql stable as $$
      select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid;
    $$;
    grant usage on schema auth to authenticated;
    grant execute on function auth.uid() to authenticated;
  `);
  await db.exec(readFileSync(new URL('../001_initial.sql',import.meta.url),'utf8'));
  await db.exec(readFileSync(new URL('../002_verify.sql',import.meta.url),'utf8'));
  console.log('PASS: IDs, Unicode, task lifecycle, ownership, capacity, chat privacy, idempotency, friendship, ratings and anonymous access.');
} finally {
  await db.close();
}
