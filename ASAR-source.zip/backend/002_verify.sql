-- Run in SQL Editor after 001_initial.sql. All test data is rolled back.
begin;
insert into auth.users(id,email_confirmed_at) values
 ('a5a00000-0000-4000-8000-000000000001',now()),
 ('a5a00000-0000-4000-8000-000000000002',now()),
 ('a5a00000-0000-4000-8000-000000000003',now());
set local role authenticated;
select set_config('request.jwt.claim.sub','a5a00000-0000-4000-8000-000000000001',true);
select public.asar_finish_profile('Әлихан Өмірбек','01020304');
select set_config('asar.test.task',public.asar_create_task('Помочь с книгами','Нужна помощь в городской библиотеке','Education','Алматы',now()+interval '1 day',1,'00000000-0000-4000-8000-000000000011')::text,true);
do $$ begin
  begin
    perform public.asar_apply_task(current_setting('asar.test.task')::bigint);
    raise exception 'FAIL own application allowed';
  exception when raise_exception then if sqlerrm<>'OWN_TASK' then raise; end if; end;
  begin
    update public.profiles set full_name='Unauthorized';
    raise exception 'FAIL direct write allowed';
  exception when insufficient_privilege then null; end;
end $$;
select set_config('request.jwt.claim.sub','a5a00000-0000-4000-8000-000000000002',true);
do $$ begin
  begin
    perform public.asar_finish_profile('Ирина','01020304');
    raise exception 'FAIL duplicate ID accepted';
  exception when raise_exception then if sqlerrm<>'ID_TAKEN' then raise; end if; end;
  begin
    perform public.asar_finish_profile('Ирина','１２３４５６７８');
    raise exception 'FAIL non-ASCII ID accepted';
  exception when raise_exception then if sqlerrm<>'INVALID_ID' then raise; end if; end;
end $$;
select public.asar_finish_profile('Ирина',null);
select public.asar_apply_task(current_setting('asar.test.task')::bigint);
select public.asar_apply_task(current_setting('asar.test.task')::bigint);
select set_config('asar.test.application',(select id::text from public.applications where volunteer_id=auth.uid()),true);
select set_config('asar.test.chat',public.asar_open_chat('a5a00000-0000-4000-8000-000000000001',current_setting('asar.test.task')::bigint)::text,true);
select public.asar_send_message(current_setting('asar.test.chat')::bigint,'Сәлем! Көмектесуге дайынмын.','00000000-0000-4000-8000-000000000012');
select public.asar_send_message(current_setting('asar.test.chat')::bigint,'Сәлем! Көмектесуге дайынмын.','00000000-0000-4000-8000-000000000012');
do $$ begin
  if (select count(*) from public.applications)<>1 then raise exception 'FAIL duplicate application'; end if;
  if (select count(*) from public.messages)<>1 then raise exception 'FAIL duplicate message'; end if;
  if (select count(*) from public.profiles)<>1 then raise exception 'FAIL profile privacy'; end if;
  begin
    perform public.asar_decide_application(current_setting('asar.test.application')::bigint,true);
    raise exception 'FAIL volunteer accepted own application';
  exception when raise_exception then if sqlerrm<>'FORBIDDEN' then raise; end if; end;
  begin
    perform public.asar_review(current_setting('asar.test.task')::bigint,'a5a00000-0000-4000-8000-000000000001',5,'Wrong review');
    raise exception 'FAIL unauthorized review';
  exception when raise_exception then if sqlerrm<>'FORBIDDEN' then raise; end if; end;
end $$;
select set_config('request.jwt.claim.sub','a5a00000-0000-4000-8000-000000000003',true);
select public.asar_finish_profile('Айгерім','12340003');
select public.asar_apply_task(current_setting('asar.test.task')::bigint);
select set_config('asar.test.other_application',(select id::text from public.applications where volunteer_id=auth.uid()),true);
do $$ begin
  if exists(select 1 from public.messages) then raise exception 'FAIL third party reads chat'; end if;
  if exists(select 1 from public.conversations) then raise exception 'FAIL third party sees conversation'; end if;
  begin
    perform public.asar_send_message(current_setting('asar.test.chat')::bigint,'intrusion','00000000-0000-4000-8000-000000000013');
    raise exception 'FAIL third party writes chat';
  exception when raise_exception then if sqlerrm<>'FORBIDDEN' then raise; end if; end;
  begin
    perform public.asar_open_chat('a5a00000-0000-4000-8000-000000000002',null);
    raise exception 'FAIL stranger opens direct chat';
  exception when raise_exception then if sqlerrm<>'FORBIDDEN' then raise; end if; end;
end $$;
select set_config('request.jwt.claim.sub','a5a00000-0000-4000-8000-000000000001',true);
select public.asar_decide_application(current_setting('asar.test.application')::bigint,true);
do $$ begin
  begin
    perform public.asar_decide_application(current_setting('asar.test.other_application')::bigint,true);
    raise exception 'FAIL overbooking';
  exception when raise_exception then if sqlerrm<>'TASK_FULL' then raise; end if; end;
end $$;
select public.asar_complete_task(current_setting('asar.test.task')::bigint);
select public.asar_review(current_setting('asar.test.task')::bigint,'a5a00000-0000-4000-8000-000000000002',5,'Спасибо за помощь!');
select public.asar_invite_friend('12340003');
select set_config('asar.test.friend',(select id::text from public.friend_requests),true);
select set_config('request.jwt.claim.sub','a5a00000-0000-4000-8000-000000000003',true);
select public.asar_decide_friend(current_setting('asar.test.friend')::bigint,true);
select public.asar_open_chat('a5a00000-0000-4000-8000-000000000001',null);
select set_config('request.jwt.claim.sub','a5a00000-0000-4000-8000-000000000002',true);
do $$ declare payload jsonb:=public.asar_snapshot(); begin
  if (payload->>'rating')::numeric<>5 then raise exception 'FAIL real rating'; end if;
  if (payload->>'completed_count')::integer<>1 then raise exception 'FAIL completion count'; end if;
  if (payload->'profile'->>'public_id') !~ '^[0-9]{8}$' then raise exception 'FAIL random ID'; end if;
  if payload->'profile'->>'full_name'<>'Ирина' then raise exception 'FAIL Unicode name'; end if;
end $$;
reset role;
set local role anon;
do $$ begin
  begin
    perform public.asar_snapshot();
    raise exception 'FAIL anonymous API access';
  exception when insufficient_privilege then null; end;
end $$;
reset role;
rollback;
select 'ASAR verification passed; test data rolled back' as result;
