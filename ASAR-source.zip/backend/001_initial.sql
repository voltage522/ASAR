-- ASAR · initial schema for a NEW Supabase project.
-- Run once as project owner in SQL Editor. Never run this as an app client.
begin;
create schema if not exists asar_private;
revoke all on schema asar_private from public, anon;
grant usage on schema asar_private to authenticated;

create table public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  public_id text not null unique check (public_id ~ '^[0-9]{8}$'),
  full_name text not null check (char_length(btrim(full_name)) between 1 and 50),
  created_at timestamptz not null default now()
);
create table public.tasks (
  id bigint generated always as identity primary key,
  owner_id uuid not null references public.profiles(user_id) on delete cascade,
  title text not null check (char_length(btrim(title)) between 5 and 120),
  description text not null check (char_length(btrim(description)) between 15 and 5000),
  category text not null check (category in ('Community','Environment','Essentials','Education','Moving')),
  area text not null check (char_length(btrim(area)) between 1 and 160),
  starts_at timestamptz not null,
  slots integer not null check (slots between 1 and 20),
  status text not null default 'Open' check (status in ('Open','Completed')),
  request_key uuid not null,
  created_at timestamptz not null default now(),
  unique(owner_id, request_key)
);
create table public.applications (
  id bigint generated always as identity primary key,
  task_id bigint not null references public.tasks(id) on delete cascade,
  volunteer_id uuid not null references public.profiles(user_id) on delete cascade,
  status text not null default 'Pending' check (status in ('Pending','Accepted','Rejected','Completed')),
  created_at timestamptz not null default now(),
  unique(task_id, volunteer_id)
);
create table public.friend_requests (
  id bigint generated always as identity primary key,
  sender_id uuid not null references public.profiles(user_id) on delete cascade,
  receiver_id uuid not null references public.profiles(user_id) on delete cascade,
  status text not null default 'Pending' check (status in ('Pending','Accepted','Rejected')),
  created_at timestamptz not null default now(),
  check (sender_id <> receiver_id)
);
create unique index friend_pair on public.friend_requests(least(sender_id,receiver_id),greatest(sender_id,receiver_id));
create table public.conversations (
  id bigint generated always as identity primary key,
  member_a uuid not null references public.profiles(user_id) on delete cascade,
  member_b uuid not null references public.profiles(user_id) on delete cascade,
  task_id bigint references public.tasks(id) on delete cascade,
  created_at timestamptz not null default now(),
  check (member_a <> member_b)
);
create unique index conversation_pair on public.conversations(least(member_a,member_b),greatest(member_a,member_b),coalesce(task_id,0));
create table public.messages (
  id bigint generated always as identity primary key,
  conversation_id bigint not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(user_id) on delete cascade,
  body text not null check (char_length(btrim(body)) between 1 and 4000),
  client_key uuid not null,
  created_at timestamptz not null default now(),
  unique(sender_id, client_key)
);
create table public.reviews (
  id bigint generated always as identity primary key,
  task_id bigint not null references public.tasks(id) on delete cascade,
  author_id uuid not null references public.profiles(user_id) on delete cascade,
  recipient_id uuid not null references public.profiles(user_id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  body text not null check (char_length(btrim(body)) between 1 and 2000),
  created_at timestamptz not null default now(),
  unique(task_id, author_id, recipient_id),
  check(author_id <> recipient_id)
);
create index tasks_owner on public.tasks(owner_id);
create index applications_volunteer on public.applications(volunteer_id);
create index messages_conversation_cursor on public.messages(conversation_id,id desc);
create index conversations_member_b on public.conversations(member_b);
create index conversations_member_a on public.conversations(member_a);
create index friend_receiver on public.friend_requests(receiver_id);
create index friend_sender on public.friend_requests(sender_id,created_at);
create index review_recipient on public.reviews(recipient_id);

create function asar_private.actor() returns uuid language plpgsql stable security definer set search_path = '' as $$
declare actor_id uuid := auth.uid();
begin
  if actor_id is null or not exists(select 1 from auth.users where id=actor_id and email_confirmed_at is not null)
    then raise exception 'AUTH_REQUIRED'; end if;
  return actor_id;
end $$;

-- Membership helper avoids recursive policies, and is not exposed through the Data API.
create function asar_private.is_member(conversation bigint) returns boolean
language sql stable security definer set search_path = '' as $$
 select exists(select 1 from public.conversations c where c.id=conversation and auth.uid() in(c.member_a,c.member_b));
$$;

alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.applications enable row level security;
alter table public.friend_requests enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.reviews enable row level security;
create policy profile_self on public.profiles for select to authenticated using(user_id=(select auth.uid()));
create policy tasks_read on public.tasks for select to authenticated using(true);
create policy applications_read on public.applications for select to authenticated using(
  volunteer_id=(select auth.uid()) or exists(select 1 from public.tasks t where t.id=task_id and t.owner_id=(select auth.uid())));
create policy friends_read on public.friend_requests for select to authenticated using((select auth.uid()) in(sender_id,receiver_id));
create policy conversations_read on public.conversations for select to authenticated using((select auth.uid()) in(member_a,member_b));
create policy messages_read on public.messages for select to authenticated using(asar_private.is_member(conversation_id));
create policy reviews_read on public.reviews for select to authenticated using((select auth.uid()) in(author_id,recipient_id));
-- No client INSERT / UPDATE / DELETE grants: all writes go through checked transactional functions.
revoke all on public.profiles,public.tasks,public.applications,public.friend_requests,public.conversations,public.messages,public.reviews from anon,authenticated;
grant select on public.profiles,public.tasks,public.applications,public.friend_requests,public.conversations,public.messages,public.reviews to authenticated;

-- Profile creation happens AFTER authentication so duplicate custom IDs can be reported
-- clearly without interfering with email verification.
create function asar_private.finish_profile(p_name text,p_id text default null) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); candidate text; n integer; result public.profiles;
begin
  if exists(select 1 from public.profiles where user_id=me) then
    select * into result from public.profiles where user_id=me; return to_jsonb(result);
  end if;
  if char_length(btrim(p_name)) not between 1 and 50 then raise exception 'INVALID_NAME'; end if;
  if nullif(btrim(p_id),'') is not null then
    if p_id !~ '^[0-9]{8}$' then raise exception 'INVALID_ID'; end if;
    begin
      insert into public.profiles(user_id,public_id,full_name) values(me,p_id,btrim(p_name)) returning * into result;
    exception when unique_violation then
      if exists(select 1 from public.profiles where user_id=me) then
        select * into result from public.profiles where user_id=me;
      else raise exception 'ID_TAKEN'; end if;
    end;
    return to_jsonb(result);
  end if;
  for n in 1..100 loop
    candidate := (floor(random()*90000000)+10000000)::bigint::text;
    begin
      insert into public.profiles(user_id,public_id,full_name) values(me,candidate,btrim(p_name)) returning * into result;
      return to_jsonb(result);
    exception when unique_violation then
      if exists(select 1 from public.profiles where user_id=me) then
        select * into result from public.profiles where user_id=me; return to_jsonb(result);
      end if;
    end;
  end loop;
  raise exception 'ID_RETRY';
end $$;

create function asar_private.rename(p_name text) returns void language plpgsql security definer set search_path = '' as $$
begin
  if char_length(btrim(p_name)) not between 1 and 50 then raise exception 'INVALID_NAME'; end if;
  update public.profiles set full_name=btrim(p_name) where user_id=asar_private.actor();
  if not found then raise exception 'PROFILE_REQUIRED'; end if;
end $$;

create function asar_private.create_task(p_title text,p_description text,p_category text,p_area text,p_date timestamptz,p_slots integer,p_key uuid)
returns bigint language plpgsql security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); result bigint;
begin
  if not exists(select 1 from public.profiles where user_id=me) then raise exception 'PROFILE_REQUIRED'; end if;
  select id into result from public.tasks where owner_id=me and request_key=p_key;
  if found then return result; end if;
  if p_date<=now() then raise exception 'INVALID_DATE'; end if;
  insert into public.tasks(owner_id,title,description,category,area,starts_at,slots,request_key)
  values(me,btrim(p_title),btrim(p_description),p_category,btrim(p_area),p_date,p_slots,p_key)
  on conflict(owner_id,request_key) do update set request_key=excluded.request_key returning id into result;
  return result;
end $$;

create function asar_private.apply_task(p_task bigint) returns void language plpgsql security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); task public.tasks;
begin
  select * into task from public.tasks where id=p_task for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if task.owner_id=me then raise exception 'OWN_TASK'; end if;
  if task.status<>'Open' or task.starts_at<now() then raise exception 'TASK_CLOSED'; end if;
  if (select count(*) from public.applications where task_id=p_task and status='Accepted')>=task.slots then raise exception 'TASK_FULL'; end if;
  insert into public.applications(task_id,volunteer_id) values(p_task,me) on conflict(task_id,volunteer_id) do nothing;
end $$;

create function asar_private.decide_application(p_application bigint,p_accept boolean) returns void
language plpgsql security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); application public.applications; task public.tasks; task_id bigint;
begin
  select a.task_id into task_id from public.applications a where a.id=p_application;
  select * into task from public.tasks where id=task_id for update;
  if not found or task.owner_id<>me then raise exception 'FORBIDDEN'; end if;
  select * into application from public.applications where id=p_application for update;
  if task.status<>'Open' then raise exception 'TASK_CLOSED'; end if;
  if application.status<>'Pending' then return; end if;
  if p_accept and (select count(*) from public.applications where applications.task_id=task.id and status='Accepted')>=task.slots then
    raise exception 'TASK_FULL';
  end if;
  update public.applications set status=case when p_accept then 'Accepted' else 'Rejected' end where id=p_application;
end $$;

create function asar_private.complete_task(p_task bigint) returns void language plpgsql security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); task public.tasks;
begin
  select * into task from public.tasks where id=p_task for update;
  if not found or task.owner_id<>me then raise exception 'FORBIDDEN'; end if;
  if task.status='Completed' then return; end if;
  if not exists(select 1 from public.applications where task_id=p_task and status='Accepted') then raise exception 'ACCEPT_FIRST'; end if;
  update public.tasks set status='Completed' where id=p_task;
  update public.applications set status=case when status='Accepted' then 'Completed' else 'Rejected' end where task_id=p_task;
end $$;

create function asar_private.review(p_task bigint,p_recipient uuid,p_rating integer,p_body text) returns void
language plpgsql security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); task public.tasks;
begin
  select * into task from public.tasks where id=p_task;
  if not found or task.owner_id<>me or task.status<>'Completed' or not exists(
    select 1 from public.applications where task_id=p_task and volunteer_id=p_recipient and status='Completed')
    then raise exception 'FORBIDDEN'; end if;
  insert into public.reviews(task_id,author_id,recipient_id,rating,body) values(p_task,me,p_recipient,p_rating,btrim(p_body))
    on conflict(task_id,author_id,recipient_id) do update set rating=excluded.rating,body=excluded.body;
end $$;

create function asar_private.invite_friend(p_id text) returns void language plpgsql security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); target uuid; existing public.friend_requests;
begin
  if p_id !~ '^[0-9]{8}$' then raise exception 'INVALID_ID'; end if;
  select user_id into target from public.profiles where public_id=p_id;
  if not found then raise exception 'PERSON_NOT_FOUND'; end if;
  if target=me then raise exception 'SELF_INVITE'; end if;
  if (select count(*) from public.friend_requests where sender_id=me and created_at>now()-interval '1 day')>=20 then raise exception 'RATE_LIMIT'; end if;
  insert into public.friend_requests(sender_id,receiver_id) values(me,target) on conflict do nothing;
  select * into existing from public.friend_requests where least(sender_id,receiver_id)=least(me,target) and greatest(sender_id,receiver_id)=greatest(me,target) for update;
  if existing.status='Rejected' then raise exception 'INVITE_DECLINED'; end if;
end $$;

create function asar_private.decide_friend(p_request bigint,p_accept boolean) returns void
language plpgsql security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); request public.friend_requests;
begin
  select * into request from public.friend_requests where id=p_request for update;
  if not found or request.receiver_id<>me then raise exception 'FORBIDDEN'; end if;
  if request.status<>'Pending' then return; end if;
  update public.friend_requests set status=case when p_accept then 'Accepted' else 'Rejected' end where id=p_request;
end $$;

create function asar_private.open_chat(p_peer uuid,p_task bigint default null) returns bigint
language plpgsql security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); result bigint; owner uuid;
begin
  if p_peer=me then raise exception 'FORBIDDEN'; end if;
  if p_task is null then
    if not exists(select 1 from public.friend_requests where status='Accepted' and least(sender_id,receiver_id)=least(me,p_peer)
      and greatest(sender_id,receiver_id)=greatest(me,p_peer)) then raise exception 'FORBIDDEN'; end if;
  else
    select owner_id into owner from public.tasks where id=p_task;
    if not found or owner not in(me,p_peer) or not exists(select 1 from public.applications
      where task_id=p_task and volunteer_id=case when owner=me then p_peer else me end and status in('Pending','Accepted','Completed'))
      then raise exception 'FORBIDDEN'; end if;
  end if;
  insert into public.conversations(member_a,member_b,task_id) values(least(me,p_peer),greatest(me,p_peer),p_task) on conflict do nothing;
  select id into result from public.conversations where member_a=least(me,p_peer) and member_b=greatest(me,p_peer) and task_id is not distinct from p_task;
  return result;
end $$;

create function asar_private.send_message(p_chat bigint,p_body text,p_key uuid) returns bigint
language plpgsql security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); result bigint;
begin
  if not asar_private.is_member(p_chat) then raise exception 'FORBIDDEN'; end if;
  -- Serialize writes per conversation before allocating a message ID. This keeps
  -- the polling cursor from skipping a lower ID committed after a newer message.
  perform 1 from public.conversations where id=p_chat for update;
  if char_length(btrim(p_body)) not between 1 and 4000 then raise exception 'INVALID_MESSAGE'; end if;
  select id into result from public.messages where sender_id=me and client_key=p_key and conversation_id=p_chat;
  if found then return result; end if;
  if (select count(*) from public.messages where sender_id=me and created_at>now()-interval '1 minute')>=30 then raise exception 'RATE_LIMIT'; end if;
  insert into public.messages(conversation_id,sender_id,body,client_key) values(p_chat,me,btrim(p_body),p_key)
    on conflict(sender_id,client_key) do nothing returning id into result;
  if result is null then
    select id into result from public.messages where sender_id=me and client_key=p_key and conversation_id=p_chat;
    if not found then raise exception 'INVALID_MESSAGE'; end if;
  end if;
  return result;
end $$;
create index message_sender_time on public.messages(sender_id,created_at);

create function asar_private.snapshot() returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare me uuid := asar_private.actor(); result jsonb;
begin
  select jsonb_build_object(
    'profile',(select to_jsonb(p) from public.profiles p where user_id=me),
    'tasks',coalesce((select jsonb_agg(x order by x.id desc) from (
      select t.*,p.full_name requester,(select count(*) from public.applications a where a.task_id=t.id and a.status in('Accepted','Completed')) confirmed
      from public.tasks t join public.profiles p on p.user_id=t.owner_id
      where (t.status='Open' and t.starts_at>now()) or t.owner_id=me or exists(select 1 from public.applications a where a.task_id=t.id and a.volunteer_id=me)
    ) x),'[]'::jsonb),
    'applications',coalesce((select jsonb_agg(x) from (
      select a.*,p.full_name name from public.applications a join public.tasks t on t.id=a.task_id join public.profiles p on p.user_id=a.volunteer_id
      where a.volunteer_id=me or t.owner_id=me
    ) x),'[]'::jsonb),
    'friends',coalesce((select jsonb_agg(x) from (
      select f.*,p.user_id peer_id,p.full_name peer_name,p.public_id peer_public_id
      from public.friend_requests f join public.profiles p on p.user_id=case when f.sender_id=me then f.receiver_id else f.sender_id end
      where me in(f.sender_id,f.receiver_id)
    ) x),'[]'::jsonb),
    'conversations',coalesce((select jsonb_agg(x order by x.last_at desc) from (
      select c.id,c.task_id,p.user_id peer_id,p.full_name peer_name,coalesce(t.title,p.full_name) title,
        (select body from public.messages m where m.conversation_id=c.id order by m.id desc limit 1) last_message,
        coalesce((select created_at from public.messages m where m.conversation_id=c.id order by m.id desc limit 1),c.created_at) last_at
      from public.conversations c join public.profiles p on p.user_id=case when c.member_a=me then c.member_b else c.member_a end
      left join public.tasks t on t.id=c.task_id where me in(c.member_a,c.member_b)
    ) x),'[]'::jsonb),
    'reviews',coalesce((select jsonb_agg(r) from public.reviews r where me in(r.author_id,r.recipient_id)),'[]'::jsonb),
    'rating',(select round(avg(rating),1) from public.reviews where recipient_id=me),
    'completed_count',(select count(*) from public.applications where volunteer_id=me and status='Completed')
  ) into result;
  return result;
end $$;

-- API wrappers have invoker privileges; privileged bodies stay outside exposed schemas.
create function public.asar_finish_profile(p_name text,p_id text default null) returns jsonb language sql security invoker set search_path='' as $$ select asar_private.finish_profile(p_name,p_id); $$;
create function public.asar_rename(p_name text) returns void language sql security invoker set search_path='' as $$ select asar_private.rename(p_name); $$;
create function public.asar_create_task(p_title text,p_description text,p_category text,p_area text,p_date timestamptz,p_slots integer,p_key uuid) returns bigint language sql security invoker set search_path='' as $$ select asar_private.create_task(p_title,p_description,p_category,p_area,p_date,p_slots,p_key); $$;
create function public.asar_apply_task(p_task bigint) returns void language sql security invoker set search_path='' as $$ select asar_private.apply_task(p_task); $$;
create function public.asar_decide_application(p_application bigint,p_accept boolean) returns void language sql security invoker set search_path='' as $$ select asar_private.decide_application(p_application,p_accept); $$;
create function public.asar_complete_task(p_task bigint) returns void language sql security invoker set search_path='' as $$ select asar_private.complete_task(p_task); $$;
create function public.asar_review(p_task bigint,p_recipient uuid,p_rating integer,p_body text) returns void language sql security invoker set search_path='' as $$ select asar_private.review(p_task,p_recipient,p_rating,p_body); $$;
create function public.asar_invite_friend(p_id text) returns void language sql security invoker set search_path='' as $$ select asar_private.invite_friend(p_id); $$;
create function public.asar_decide_friend(p_request bigint,p_accept boolean) returns void language sql security invoker set search_path='' as $$ select asar_private.decide_friend(p_request,p_accept); $$;
create function public.asar_open_chat(p_peer uuid,p_task bigint default null) returns bigint language sql security invoker set search_path='' as $$ select asar_private.open_chat(p_peer,p_task); $$;
create function public.asar_send_message(p_chat bigint,p_body text,p_key uuid) returns bigint language sql security invoker set search_path='' as $$ select asar_private.send_message(p_chat,p_body,p_key); $$;
create function public.asar_snapshot() returns jsonb language sql stable security invoker set search_path='' as $$ select asar_private.snapshot(); $$;

-- Remove PostgreSQL's default PUBLIC function-execute privilege from ASAR functions only.
do $$ declare f record;
begin
  for f in select p.oid::regprocedure signature from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='asar_private' or (n.nspname='public' and p.proname like 'asar_%')
  loop
    execute format('revoke all on function %s from public, anon',f.signature);
    execute format('grant execute on function %s to authenticated',f.signature);
  end loop;
end $$;
commit;

