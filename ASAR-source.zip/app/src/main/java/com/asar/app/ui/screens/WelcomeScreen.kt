package com.asar.app.ui.screens

import android.util.Patterns
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.asar.app.R
import com.asar.app.data.AsarState
import com.asar.app.ui.LocalStrings
import com.asar.app.ui.components.*

@Composable
fun WelcomeScreen(state: AsarState) {
    val s = LocalStrings.current
    var mode by rememberSaveable { mutableStateOf("login") }
    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var publicId by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    var recovery by rememberSaveable { mutableStateOf(false) }
    var invalid by rememberSaveable { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
        .verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { AsarBrand() }
            LanguagePicker(state,compact=true)
        }
        Spacer(Modifier.height(12.dp))
        PageHeading(s(when(mode) {
            "register" -> R.string.register_title
            "code" -> R.string.verify_title
            "recover" -> R.string.recover_title
            else -> R.string.welcome_title
        }), s(if(mode=="code") R.string.verify_hint else R.string.welcome_body))
        if(!state.configured) InfoPanel(s(R.string.setup_wait),s(R.string.setup_wait_body))
        if(mode=="register") {
            NameField(name,{name=it})
            OutlinedTextField(publicId,{publicId=it},label={Text(s(R.string.public_id_optional))},
                supportingText={Text(s(R.string.public_id_hint))},singleLine=true,
                keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth())
        }
        OutlinedTextField(email,{email=it; invalid=false},label={Text(s(R.string.email))},singleLine=true,
            enabled=!state.busy,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Email),modifier=Modifier.fillMaxWidth())
        if(mode=="login" || mode=="register") OutlinedTextField(password,{password=it; invalid=false},
            label={Text(s(R.string.password))},singleLine=true,enabled=!state.busy,
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Password),
            visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
        if(mode=="code") OutlinedTextField(code,{code=it},label={Text(s(R.string.email_code))},singleLine=true,
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth())
        if(invalid) Text(s(R.string.auth_error),color=MaterialTheme.colorScheme.error)
        state.error?.let { Text(s.failure(it),color=MaterialTheme.colorScheme.error) }
        state.notice?.let { Text(s.failure(it),color=MaterialTheme.colorScheme.primary) }
        if(state.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        PrimaryButton(s(when(mode) {
            "register" -> R.string.signup
            "recover" -> R.string.send_code
            "code" -> R.string.verify
            else -> R.string.login
        }),enabled=state.configured && !state.busy) {
            invalid=!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() ||
                ((mode=="login" || mode=="register") && password.isEmpty()) || (mode=="code" && code.isBlank())
            if(!invalid) when(mode) {
                "register" -> state.signup(name,email,password,publicId) { mode="code"; recovery=false; password="" }
                "recover" -> state.recover(email) { mode="code"; recovery=true }
                "code" -> state.verify(email,code,recovery)
                else -> state.login(email,password)
            }
        }
        if(mode=="login") {
            OutlinedButton(onClick={mode="register";state.error=null},enabled=!state.busy,modifier=Modifier.fillMaxWidth()) {Text(s(R.string.signup))}
            TextButton(onClick={mode="recover";state.error=null},enabled=!state.busy) {Text(s(R.string.forgot_password))}
            TextButton(onClick={mode="code";recovery=false;state.error=null},enabled=!state.busy) {Text(s(R.string.confirm_email))}
        } else {
            if(mode=="code") TextButton(onClick={if(recovery) state.recover(email) {} else state.resend(email)},
                enabled=!state.busy && Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {Text(s(R.string.resend_code))}
            TextButton(onClick={mode="login";state.error=null;state.notice=null;password="";code=""},enabled=!state.busy) {Text(s(R.string.back))}
        }
        Text(s(R.string.auth_note),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun CompleteAccountScreen(state: AsarState) {
    val s=LocalStrings.current
    var name by rememberSaveable {mutableStateOf(state.user?.name.orEmpty())}
    var publicId by rememberSaveable {mutableStateOf(state.requestedId)}
    var password by remember {mutableStateOf("")}
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
        .verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(20.dp)) {
        AsarBrand(large=true)
        LanguagePicker(state,compact=true)
        PageHeading(s(if(state.passwordRecovery) R.string.recover_title else R.string.profile_setup))
        if(state.passwordRecovery) OutlinedTextField(password,{password=it},label={Text(s(R.string.new_password))},
            visualTransformation=PasswordVisualTransformation(),singleLine=true,modifier=Modifier.fillMaxWidth())
        else {
            NameField(name,{name=it})
            OutlinedTextField(publicId,{publicId=it},label={Text(s(R.string.public_id_optional))},
                supportingText={Text(s(R.string.public_id_hint))},singleLine=true,
                keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth())
        }
        state.error?.let {Text(s.failure(it),color=MaterialTheme.colorScheme.error)}
        if(state.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        PrimaryButton(s(R.string.save_profile),enabled=!state.busy && state.configured) {
            if(state.passwordRecovery) state.changePassword(password) else state.finishProfile(name,publicId)
        }
        TextButton(onClick={state.signOut()},enabled=!state.busy) {Text(s(R.string.logout))}
    }
}

