package com.asar.app.network

import com.asar.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class AsarRepository(private val api: SupabaseApi, private val store: SessionStore) {
    private val authLock = Mutex()
    @Volatile var session: AuthSession? = null
        private set
    val configured get() = api.configured

    suspend fun restore(): AuthSession? = authLock.withLock {
        session = withContext(Dispatchers.IO) { store.read() }
        session
    }
    private suspend fun save(value: AuthSession) {
        withContext(Dispatchers.IO) { store.write(value) }
        session = value
    }
    suspend fun login(email: String,password: String) = authLock.withLock {
        val response = api.request("/auth/v1/token?grant_type=password","POST",
            JSONObject().put("email",email.trim()).put("password",password))
        save(AuthSession.response(JSONObject(response)))
    }
    suspend fun signup(name: String,email: String,password: String,requestedId: String): Boolean = authLock.withLock {
        val response = JSONObject(api.request("/auth/v1/signup","POST",JSONObject()
            .put("email",email.trim()).put("password",password)
            .put("data",JSONObject().put("full_name",name.trim()).put("public_id",requestedId))))
        if(response.has("access_token")) { save(AuthSession.response(response)); true } else false
    }
    suspend fun resend(email: String) {
        api.request("/auth/v1/resend","POST",JSONObject().put("type","signup").put("email",email.trim()))
    }
    suspend fun recover(email: String) {
        api.request("/auth/v1/recover","POST",JSONObject().put("email",email.trim()))
    }
    suspend fun verify(email: String,code: String,recovery: Boolean) = authLock.withLock {
        val response = api.request("/auth/v1/verify","POST",JSONObject()
            .put("email",email.trim()).put("token",code.trim()).put("type",if(recovery) "recovery" else "signup"))
        save(AuthSession.response(JSONObject(response)))
    }
    private suspend fun token(forceFor: String? = null): String = authLock.withLock {
        val current = session ?: throw ApiFailure(401,"AUTH_REQUIRED","")
        if(current.expiresAt > System.currentTimeMillis()/1000+60 && (forceFor == null || forceFor != current.access)) return@withLock current.access
        try {
            val response = api.request("/auth/v1/token?grant_type=refresh_token","POST",JSONObject().put("refresh_token",current.refresh))
            val updated = AuthSession.response(JSONObject(response),current)
            save(updated)
            updated.access
        } catch(e: ApiFailure) {
            if(e.status in listOf(400,401,403)) { session = null; withContext(Dispatchers.IO) { store.clear() } }
            throw e
        }
    }
    suspend fun authenticated(path: String,method: String = "GET",body: JSONObject? = null): String {
        val first = token()
        return try { api.request(path,method,body,first) }
        catch(e: ApiFailure) {
            if(e.status != 401) throw e
            api.request(path,method,body,token(first))
        }
    }
    suspend fun rpc(name: String,body: JSONObject = JSONObject()) = authenticated("/rest/v1/rpc/asar_$name","POST",body)
    suspend fun changePassword(password: String) { authenticated("/auth/v1/user","PUT",JSONObject().put("password",password)) }
    suspend fun logout(): Boolean {
        // Local token deletion is guaranteed even when the network is unavailable.
        return authLock.withLock {
            val current = session
            session = null
            withContext(Dispatchers.IO) { store.clear() }
            if(current == null) return@withLock true
            runCatching { api.request("/auth/v1/logout?scope=local","POST",JSONObject(),current.access) }.isSuccess
        }
    }
    suspend fun snapshot(): Snapshot {
        val payload = JSONObject(rpc("snapshot"))
        val current = session ?: throw ApiFailure(401,"AUTH_REQUIRED","")
        val profile = payload.optJSONObject("profile")
        val user = profile?.let { User(current.userId,it.getString("full_name"),current.email,it.getString("public_id")) }
        if(user != null) authLock.withLock {
            // Never restore an account that was signed out while this read was running.
            session?.takeIf { it.userId == user.id }?.let { save(it.copy(name=user.name,publicId=user.publicId)) }
        }
        return Snapshot(
            user,
            payload.getJSONArray("tasks").objects { HelpTask(
                id=it.getLong("id"),title=it.getString("title"),description=it.getString("description"),
                category=Category.valueOf(it.getString("category")),area=it.getString("area"),date=it.getString("starts_at"),
                slots=it.getInt("slots"),requester=it.getString("requester"),ownerId=it.getString("owner_id"),
                owned=it.getString("owner_id")==current.userId,completed=it.getString("status")=="Completed",
                confirmed=it.getInt("confirmed"),skills=TaskAnalyzer.analyze(it.getString("title")+" "+it.getString("description")).skills
            ) },
            payload.getJSONArray("applications").objects { Application(it.getLong("id"),it.getLong("task_id"),
                it.getString("name"),it.getString("volunteer_id")==current.userId,it.getString("volunteer_id"),ApplicationStatus.valueOf(it.getString("status"))) },
            payload.getJSONArray("reviews").objects { Review(it.getLong("id"),it.getLong("task_id"),it.getString("recipient_id"),it.getInt("rating"),it.getString("body")) },
            payload.getJSONArray("friends").objects { FriendRequest(it.getLong("id"),it.getString("peer_id"),it.getString("peer_name"),
                it.getString("peer_public_id"),it.getString("receiver_id")==current.userId,it.getString("status")) },
            payload.getJSONArray("conversations").objects { Conversation(it.getLong("id"),it.getString("peer_id"),
                it.getString("peer_name"),it.getString("title"),it.optString("last_message").takeUnless { s -> s=="null" }.orEmpty()) },
            if(payload.isNull("rating")) null else payload.getDouble("rating"),payload.getInt("completed_count")
        )
    }
    suspend fun messages(chatId: Long,after: Long? = null,before: Long? = null): List<ChatMessage> {
        val cursor = if(after != null) "&id=gt.$after" else if(before != null) "&id=lt.$before" else ""
        val order = if(after != null) "asc" else "desc"
        val result = authenticated("/rest/v1/messages?conversation_id=eq.$chatId&select=id,conversation_id,sender_id,body,created_at,client_key&order=id.$order&limit=50$cursor")
        return JSONArray(result).objects { ChatMessage(it.getLong("id"),it.getLong("conversation_id"),it.getString("sender_id"),
            it.getString("body"),it.getString("created_at"),it.getString("client_key")) }.sortedBy { it.id }
    }
}
private fun <T> JSONArray.objects(map: (JSONObject) -> T): List<T> = (0 until length()).map { map(getJSONObject(it)) }

