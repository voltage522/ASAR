package com.asar.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.asar.app.R
import com.asar.app.data.AsarState
import com.asar.app.data.Language
import com.asar.app.ui.LocalStrings

@Composable
fun LanguagePicker(state: AsarState, compact: Boolean = false) {
    val s = LocalStrings.current
    var open by remember { mutableStateOf(false) }
    if(compact) TextButton(onClick = { open = true }) { Text(state.language.label) }
    else OutlinedCard(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
        ListItem(
            headlineContent = { Text(s(R.string.language)) },
            supportingContent = { Text(state.language.label) },
            trailingContent = { Text("›", style = MaterialTheme.typography.headlineSmall) },
            colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surface)
        )
    }
    if(open) AlertDialog(
        onDismissRequest = { open = false },
        title = { Text(s(R.string.language)) },
        text = {
            Column {
                Column(Modifier.selectableGroup()) {
                    Language.entries.forEach { language ->
                        Row(
                            Modifier.fillMaxWidth().selectable(
                                selected = state.language == language,
                                role = Role.RadioButton,
                                onClick = { state.language = language; open = false }
                            ).padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = state.language == language, onClick = null)
                            Spacer(Modifier.width(12.dp))
                            Text(language.label)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(s(R.string.language_note), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = { open = false }) { Text(s(R.string.cancel)) } }
    )
}

