package com.asar.app.ui

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.asar.app.R
import com.asar.app.data.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class AppStrings(private val context: Context, val language: Language) {
    val locale: Locale = Locale.forLanguageTag(language.tag)
    operator fun invoke(id: Int, vararg args: Any): String = context.getString(id, *args)
    fun category(value: Category) = invoke(when(value) {
        Category.All -> R.string.all
        Category.Community -> R.string.community
        Category.Environment -> R.string.environment
        Category.Essentials -> R.string.essentials
        Category.Education -> R.string.education
        Category.Moving -> R.string.moving
    })
    fun role(value: Role) = invoke(if(value == Role.Volunteer) R.string.volunteer else R.string.requester)
    fun status(value: ApplicationStatus) = invoke(when(value) {
        ApplicationStatus.Pending -> R.string.pending
        ApplicationStatus.Accepted -> R.string.accepted
        ApplicationStatus.Rejected -> R.string.rejected
        ApplicationStatus.Completed -> R.string.completed
    })
    fun skill(value: String): String = skillIds[value]?.let { invoke(it) } ?: value
    fun difficulty(value: String) = invoke(when(value) {
        "Light" -> R.string.light
        "Moderate" -> R.string.moderate
        else -> R.string.high
    })
    fun applicant(application: Application) = application.name
    fun failure(code: String) = invoke(when(code) {
        "NETWORK" -> R.string.error_network
        "NETWORK_TIMEOUT" -> R.string.error_network_timeout
        "NETWORK_DNS" -> R.string.error_network_dns
        "NETWORK_TLS" -> R.string.error_network_tls
        "NETWORK_CONNECT" -> R.string.error_network_connect
        "EMAIL_NOT_AUTHORIZED" -> R.string.error_email_unauthorized
        "INVALID_EMAIL" -> R.string.auth_error
        "ACCOUNT_EXISTS" -> R.string.error_account_exists
        "SMTP_FAILED" -> R.string.error_smtp
        "NOT_CONFIGURED", "SERVER_SETUP" -> R.string.error_setup
        "AUTH_REQUIRED" -> R.string.error_auth
        "AUTH_FAILED" -> R.string.error_credentials
        "WEAK_PASSWORD" -> R.string.error_weak_password
        "VERIFY_EMAIL" -> R.string.error_verify_email
        "BAD_CODE" -> R.string.error_bad_code
        "INVALID_NAME" -> R.string.name_error
        "INVALID_ID" -> R.string.error_id
        "ID_TAKEN", "ID_RETRY" -> R.string.error_id_taken
        "FORBIDDEN", "OWN_TASK" -> R.string.error_forbidden
        "TASK_CLOSED" -> R.string.error_closed
        "TASK_FULL" -> R.string.error_full
        "ACCEPT_FIRST" -> R.string.accept_first
        "INVALID_DATE" -> R.string.date_error
        "PERSON_NOT_FOUND" -> R.string.error_person
        "SELF_INVITE" -> R.string.error_self
        "RATE_LIMIT" -> R.string.error_rate
        "INVITE_DECLINED" -> R.string.error_declined
        "INVALID_MESSAGE" -> R.string.error_message
        "LOCAL_SIGNOUT" -> R.string.local_signout
        "CODE_SENT" -> R.string.code_sent
        "ID_COPIED" -> R.string.id_copied
        "INVITE_SENT" -> R.string.invite_sent
        else -> R.string.error_server
    })
    fun date(value: String): String {
        val parsed = runCatching {
            java.time.OffsetDateTime.parse(value).atZoneSameInstant(java.time.ZoneId.systemDefault()).toLocalDateTime()
        }.getOrElse { runCatching { LocalDateTime.parse(value) }.getOrNull() }
        return parsed?.format(DateTimeFormatter.ofPattern("d MMM yyyy · HH:mm", locale)) ?: value
    }
    fun task(value: HelpTask) = value.copy(date = date(value.date), skills = value.skills.map { skill(it) })
}

private val skillIds = mapOf(
    "Teamwork" to R.string.teamwork, "Communication" to R.string.communication,
    "Organisation" to R.string.organisation, "Outdoor work" to R.string.outdoor,
    "Safe lifting" to R.string.safe_lifting, "Mentoring" to R.string.mentoring,
    "English" to R.string.english, "Assembly" to R.string.assembly,
    "Reading" to R.string.reading, "Carrying light bags" to R.string.light_bags,
    "Gardening" to R.string.gardening, "Digital skills" to R.string.digital,
    "Patience" to R.string.patience, "Attention to detail" to R.string.attention,
    "Carrying light boxes" to R.string.light_boxes, "Kazakh" to R.string.kazakh,
    "Event setup" to R.string.event_setup
)
val LocalStrings = staticCompositionLocalOf<AppStrings> { error("Provide AppLanguage first") }

@Composable
fun AppLanguage(language: Language, content: @Composable () -> Unit) {
    val base = LocalContext.current
    val configuration = LocalConfiguration.current
    val translated = remember(base, configuration, language) {
        val config = Configuration(configuration)
        config.setLocales(LocaleList(Locale.forLanguageTag(language.tag)))
        base.createConfigurationContext(config)
    }
    val strings = remember(translated, language) { AppStrings(translated, language) }
    CompositionLocalProvider(
        LocalContext provides translated,
        LocalConfiguration provides translated.resources.configuration,
        LocalStrings provides strings,
        content = content
    )
}


