package com.asar.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val AsarColors = lightColorScheme(
    primary = AccentBlue, onPrimary = Color.White,
    primaryContainer = SoftBlue, onPrimaryContainer = Ink,
    secondary = AccentBlue, onSecondary = Color.White,
    secondaryContainer = Mint, onSecondaryContainer = Ink,
    tertiary = Ink, onTertiary = Color.White,
    tertiaryContainer = Mint, onTertiaryContainer = Ink,
    background = AppBackground, onBackground = Ink,
    surface = AppBackground, onSurface = Ink,
    surfaceVariant = SoftBlue, onSurfaceVariant = Muted,
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFEEF3FA),
    surfaceContainer = Color(0xFFE8EFF8),
    surfaceContainerHigh = SoftBlue,
    surfaceContainerHighest = Color(0xFFD3E0F2),
    outline = Muted, outlineVariant = Color(0xFFC8D5E6)
)
private val AsarShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp), small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp), large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(28.dp)
)
@Composable
fun ASARTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AsarColors, typography = Typography, shapes = AsarShapes, content = content)
}

