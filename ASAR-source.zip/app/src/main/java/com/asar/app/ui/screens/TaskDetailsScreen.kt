package com.asar.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.asar.app.R
import com.asar.app.data.*
import com.asar.app.ui.LocalStrings
import com.asar.app.ui.components.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaskDetailsScreen(state: AsarState, task: HelpTask, onBack: () -> Unit, notify: (String) -> Unit) {
    val s=LocalStrings.current
    val display=s.task(task)
    val mine=state.applications.firstOrNull {it.taskId==task.id && it.mine}
    val applicants=state.applications.filter {it.taskId==task.id}
    val accepted=state.accepted(task.id)
    Column(Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement=Arrangement.spacedBy(20.dp)) {
        TextButton(onClick=onBack){Text(s(R.string.back))}
        FlowRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Pill(s.category(task.category))
            Pill(s(if(task.completed) R.string.completed else if(accepted>=task.slots) R.string.full else R.string.open))
        }
        Text(task.title,style=MaterialTheme.typography.headlineMedium)
        InfoPanel(display.area,display.date) {
            Text(s(R.string.confirmed,accepted,task.slots))
            LinearProgressIndicator(progress={accepted.toFloat()/task.slots},modifier=Modifier.fillMaxWidth())
        }
        Text(s(R.string.about_request),style=MaterialTheme.typography.titleLarge)
        Text(task.description,style=MaterialTheme.typography.bodyLarge)
        InfoPanel(s(R.string.hosted_by,task.requester),s(R.string.personal_requester))
        if(display.skills.isNotEmpty()) {
            Text(s(R.string.skills),style=MaterialTheme.typography.titleMedium)
            Text(display.skills.joinToString(" · "))
        }
        if(task.owned) Text(s(R.string.own_task_hint),style=MaterialTheme.typography.bodySmall)
        if(!task.owned && state.role==Role.Volunteer) {
            if(mine!=null) {
                InfoPanel(s.status(mine.status),s(if(mine.status==ApplicationStatus.Pending) R.string.pending_hint else R.string.status_hint))
                if(mine.status!=ApplicationStatus.Rejected) FilledTonalButton(enabled=!state.busy,onClick={state.openChat(task.ownerId,task.id)}){Text(s(R.string.chat))}
            } else if(!task.completed) PrimaryButton(s(R.string.apply),enabled=accepted<task.slots && !state.busy) {
                state.apply(task){notify(s(R.string.application_sent))}
            }
        }
        if(task.owned && state.role==Role.Requester) {
            Text(s(R.string.applications),style=MaterialTheme.typography.titleLarge)
            if(applicants.isEmpty()) InfoPanel(s(R.string.no_applicants),s(R.string.no_applicants_hint))
            applicants.forEach { application ->
                InfoPanel(application.name,s.status(application.status)) {
                    if(application.status==ApplicationStatus.Pending && !task.completed) FlowRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        Button(enabled=accepted<task.slots && !state.busy,onClick={state.decide(application,true)}){Text(s(R.string.accept))}
                        OutlinedButton(enabled=!state.busy,onClick={state.decide(application,false)}){Text(s(R.string.reject))}
                    }
                    if(application.status!=ApplicationStatus.Rejected) TextButton(enabled=!state.busy,onClick={state.openChat(application.volunteerId,task.id)}){Text(s(R.string.chat))}
                }
            }
            if(!task.completed) PrimaryButton(s(R.string.complete_task),enabled=accepted>0 && !state.busy){state.complete(task)}
        }
        if(task.completed) {
            InfoPanel(s(R.string.thank_you),s(R.string.completed_hint))
            if(task.owned && state.role==Role.Requester) applicants.filter {it.status==ApplicationStatus.Completed}.forEach { application ->
                val review=state.reviews.firstOrNull {it.taskId==task.id && it.recipientId==application.volunteerId}
                if(review==null) ReviewEditor(state,task.id,application)
                else InfoPanel(application.name,"★".repeat(review.rating)){Text(review.text)}
            } else state.reviews.filter {it.taskId==task.id && it.recipientId==state.user?.id}.forEach { review ->
                InfoPanel(s(R.string.rating),"★".repeat(review.rating)){Text(review.text)}
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ReviewEditor(state: AsarState,taskId: Long,application: Application) {
    val s=LocalStrings.current
    var text by rememberSaveable(taskId,application.id){mutableStateOf("")}
    var rating by rememberSaveable(taskId,application.id){mutableIntStateOf(5)}
    Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text(s(R.string.review_person,application.name),style=MaterialTheme.typography.titleMedium)
        FlowRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            (1..5).forEach {value->FilterChip(rating==value,{rating=value},label={Text("$value ★")})}
        }
        OutlinedTextField(text,{if(it.length<=2000) text=it},label={Text(s(R.string.review_field))},
            minLines=3,modifier=Modifier.fillMaxWidth(),enabled=!state.busy)
        PrimaryButton(s(R.string.save_review),enabled=text.isNotBlank() && !state.busy){state.review(taskId,application.volunteerId,rating,text)}
    }
}
