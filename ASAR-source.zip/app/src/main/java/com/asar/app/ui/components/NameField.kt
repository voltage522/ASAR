package com.asar.app.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.intl.LocaleList
import com.asar.app.R
import com.asar.app.data.Language
import com.asar.app.ui.LocalStrings

/** Keeps names as Unicode text, including all Kazakh and Russian letters. */
@Composable
fun NameField(value: String, onValueChange: (String) -> Unit, isError: Boolean = false) {
    val s = LocalStrings.current
    val focus = LocalFocusManager.current
    val languages = when(s.language) {
        Language.Kazakh -> "kk,ru,en"
        Language.Russian -> "ru,kk,en"
        Language.English -> "en,kk,ru"
    }
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(s(R.string.name)) },
        supportingText = { Text(s(if(isError) R.string.name_error else R.string.name_hint)) },
        singleLine = true,
        isError = isError,
        keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.Words,
            autoCorrectEnabled = false,
            keyboardType = KeyboardType.Text,
            imeAction = ImeAction.Done,
            hintLocales = LocaleList(languages)
        ),
        keyboardActions = KeyboardActions(onDone = { focus.clearFocus() }),
        modifier = Modifier.fillMaxWidth()
    )
}
