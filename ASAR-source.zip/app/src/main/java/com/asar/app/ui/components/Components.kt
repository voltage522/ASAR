package com.asar.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.asar.app.R
import com.asar.app.ui.LocalStrings
import com.asar.app.data.*
import com.asar.app.ui.theme.*

@Composable
fun NavGlyph(kind: Int, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(24.dp)) {
        val s = size.width / 24
        fun point(x: Float, y: Float) = Offset(x*s, y*s)
        val stroke = Stroke(1.8f*s)
        when(kind) {
            0 -> {
                val p = Path().apply { moveTo(3*s, 11*s); lineTo(12*s, 3*s); lineTo(21*s, 11*s); moveTo(5*s, 10*s); lineTo(5*s, 21*s); lineTo(19*s, 21*s); lineTo(19*s, 10*s) }
                drawPath(p, color, style=stroke)
                drawRect(color, point(10f,14f), androidx.compose.ui.geometry.Size(4*s,7*s), style=stroke)
            }
            1 -> {
                drawRoundRect(color, point(5f,4f), androidx.compose.ui.geometry.Size(14*s,17*s), androidx.compose.ui.geometry.CornerRadius(2*s), style=stroke)
                drawLine(color, point(8f,10f), point(16f,10f), 1.8f*s)
                drawLine(color, point(8f,15f), point(14f,15f), 1.8f*s)
            }
            2 -> { drawCircle(color, 9*s, style=stroke); drawLine(color, point(7f,12f),point(17f,12f),1.8f*s); drawLine(color,point(12f,7f),point(12f,17f),1.8f*s) }
            3 -> { drawCircle(color,4*s,point(12f,7f),style=stroke); drawArc(color,180f,180f,false,point(4f,13f), androidx.compose.ui.geometry.Size(16*s,14*s),style=stroke) }
            5 -> {
                val p = Path().apply { moveTo(4*s,4*s); lineTo(20*s,4*s); lineTo(20*s,17*s); lineTo(10*s,17*s); lineTo(4*s,21*s); close() }
                drawPath(p,color,style=stroke)
                drawLine(color,point(8f,9f),point(16f,9f),1.8f*s)
                drawLine(color,point(8f,13f),point(13f,13f),1.8f*s)
            }
            else -> { drawCircle(color,7*s,point(10f,10f),style=stroke); drawLine(color,point(15f,15f),point(21f,21f),1.8f*s) }
        }
    }
}

@Composable
fun Pill(text: String) {
    Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.small) {
        Text(text, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
        Text(text, modifier = Modifier.padding(vertical = 4.dp))
    }
}

@Composable
fun PageHeading(title: String, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        if(subtitle != null) Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun InfoPanel(title: String, text: String, content: @Composable ColumnScope.() -> Unit = {}) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable
fun TaskCard(task: HelpTask, accepted: Int, onClick: () -> Unit) {
    val s = LocalStrings.current
    val display = s.task(task)
    ElevatedCard(onClick = onClick, shape = MaterialTheme.shapes.large,
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(s.category(task.category), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text(display.title, style = MaterialTheme.typography.titleLarge)
            Text(s(R.string.hosted_by, task.requester), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(display.area + "\n" + display.date, style = MaterialTheme.typography.bodyMedium)
            Pill(s(if(task.completed) R.string.completed else if(accepted >= task.slots) R.string.full else R.string.open))
            HorizontalDivider()
            Text(s(R.string.spots, (task.slots - accepted).coerceAtLeast(0), task.slots), style = MaterialTheme.typography.bodySmall)
            FilledTonalButton(onClick = onClick, modifier = Modifier.align(Alignment.End)) { Text(s(R.string.view_request)) }
        }
    }
}

