package com.asar.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.asar.app.R
import com.asar.app.data.AsarState
import com.asar.app.ui.LocalStrings
import com.asar.app.ui.components.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.util.UUID

@Composable
fun MessagesScreen(state: AsarState) {
    val s=LocalStrings.current
    LazyColumn(contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item {PageHeading(s(R.string.messages))}
        if(state.conversations.isEmpty()) item {InfoPanel(s(R.string.messages),s(R.string.conversations_empty))}
        items(state.conversations,key={it.id}){chat->
            ElevatedCard(onClick={state.showChat(chat.id)},modifier=Modifier.fillMaxWidth()){
                ListItem(headlineContent={Text(chat.peerName)},overlineContent={Text(chat.title)},
                    supportingContent={Text(chat.lastMessage.ifBlank {s(R.string.chat_empty)},maxLines=2)},
                    colors=ListItemDefaults.colors(containerColor=MaterialTheme.colorScheme.surfaceContainerLowest))
            }
        }
    }
}

@Composable
fun ChatScreen(state: AsarState) {
    val s=LocalStrings.current
    val chatId=state.activeChat ?: return
    val chat=state.conversations.firstOrNull {it.id==chatId}
    val lifecycle=LocalLifecycleOwner.current.lifecycle
    val scroll=rememberLazyListState()
    var draft by rememberSaveable(chatId){mutableStateOf("")}
    var key by rememberSaveable(chatId){mutableStateOf(UUID.randomUUID().toString())}
    LaunchedEffect(chatId,lifecycle){
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED){
            while(isActive){state.refreshMessages();delay(4000)}
        }
    }
    val last=state.messages.lastOrNull()
    LaunchedEffect(last?.id){
        val nearBottom=(scroll.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0)>=state.messages.size-3
        if(state.messages.isNotEmpty() && (nearBottom || last?.senderId==state.user?.id || scroll.layoutInfo.totalItemsCount==0))
            scroll.animateScrollToItem(state.messages.lastIndex+1)
    }
    Column(Modifier.fillMaxSize().imePadding()){
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){
            TextButton(onClick={state.closeChat()}){Text(s(R.string.back))}
            Text(chat?.peerName ?: s(R.string.chat),style=MaterialTheme.typography.titleMedium,modifier=Modifier.weight(1f))
        }
        state.chatError?.let {Text(s.failure(it),color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(16.dp))}
        LazyColumn(state=scroll,modifier=Modifier.weight(1f).fillMaxWidth(),contentPadding=PaddingValues(16.dp),
            verticalArrangement=Arrangement.spacedBy(10.dp)){
            item {
                if(state.hasOlderMessages) TextButton(enabled=!state.busy,onClick={state.olderMessages()}){Text(s(R.string.older_messages))}
                if(state.messages.isEmpty()) Text(s(R.string.chat_empty),color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(state.messages,key={it.id}){message->
                val mine=message.senderId==state.user?.id
                Box(Modifier.fillMaxWidth(),contentAlignment=if(mine) Alignment.CenterEnd else Alignment.CenterStart){
                    Surface(shape=MaterialTheme.shapes.large,color=if(mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
                        modifier=Modifier.widthIn(max=310.dp)){
                        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                            Text(message.body,style=MaterialTheme.typography.bodyLarge)
                            Text(s.date(message.createdAt),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.Bottom){
            OutlinedTextField(draft,{if(it.length<=4000){draft=it;key=UUID.randomUUID().toString()}},label={Text(s(R.string.write_message))},enabled=!state.busy,
                modifier=Modifier.weight(1f),maxLines=5,shape=MaterialTheme.shapes.extraLarge)
            FilledTonalButton(enabled=draft.isNotBlank() && !state.busy,onClick={
                state.sendMessage(draft,key){draft="";key=UUID.randomUUID().toString()}
            }){Text(s(R.string.send))}
        }
    }
}

