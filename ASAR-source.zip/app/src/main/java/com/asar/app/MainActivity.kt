package com.asar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.lifecycle.ViewModelProvider
import com.asar.app.data.AsarState
import com.asar.app.ui.theme.ASARTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT), navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT))
        val state = ViewModelProvider(this)[AsarState::class.java]
        state.initialize(applicationContext)
        setContent { com.asar.app.ui.AppLanguage(state.language) { ASARTheme { androidx.compose.material3.Surface { AsarApp(state) } } } }
    }
}






