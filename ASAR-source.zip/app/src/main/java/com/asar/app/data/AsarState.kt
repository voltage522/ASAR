package com.asar.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import com.asar.app.network.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId

class AsarState : ViewModel() {
    private val scope = CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private var repository: AsarRepository? = null
    private var preferences: SharedPreferences? = null
    private var generation = 0
    private var _language by mutableStateOf(Language.Russian)
    var language: Language
        get() = _language
        set(value) { _language=value; preferences?.edit()?.putString("language",value.name)?.apply() }
    private var _role by mutableStateOf(Role.Volunteer)
    var role: Role
        get() = _role
        set(value) { _role=value; preferences?.edit()?.putString("role",value.name)?.apply() }
    var user by mutableStateOf<User?>(null); private set
    var configured by mutableStateOf(false); private set
    var restoring by mutableStateOf(true); private set
    var needsProfile by mutableStateOf(false); private set
    var passwordRecovery by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null)
    var notice by mutableStateOf<String?>(null)
    var connected by mutableStateOf(false); private set
    var rating by mutableStateOf<Double?>(null); private set
    var completedCount by mutableIntStateOf(0); private set
    var requestedId by mutableStateOf(""); private set
    val tasks = mutableStateListOf<HelpTask>()
    val applications = mutableStateListOf<Application>()
    val reviews = mutableStateListOf<Review>()
    val friends = mutableStateListOf<FriendRequest>()
    val conversations = mutableStateListOf<Conversation>()
    var activeChat by mutableStateOf<Long?>(null); private set
    val messages = mutableStateListOf<ChatMessage>()
    var chatError by mutableStateOf<String?>(null); private set
    var hasOlderMessages by mutableStateOf(false); private set
    private var chatLoaded = false
    private var snapshotLoading = false
    private var chatLoading = false

    fun initialize(context: Context) {
        if(repository != null) return
        preferences=context.getSharedPreferences("asar-settings",Context.MODE_PRIVATE)
        _language=runCatching { Language.valueOf(preferences!!.getString("language","Russian")!!) }.getOrDefault(Language.Russian)
        _role=runCatching { Role.valueOf(preferences!!.getString("role","Volunteer")!!) }.getOrDefault(Role.Volunteer)
        repository=AsarRepository(SupabaseApi(),SessionStore(context))
        configured=repository!!.configured
        scope.launch {
            try {
                val session=repository!!.restore()
                if(session != null) {
                    user=User(session.userId,session.name,session.email,session.publicId)
                    requestedId=session.requestedId
                    needsProfile=session.publicId.isBlank()
                    if(configured) hydrate()
                }
            } catch(e: Exception) { handle(e) }
            finally { restoring=false }
        }
    }
    private fun repo()=repository ?: error("Not initialized")
    private fun action(onSuccess: () -> Unit = {}, block: suspend () -> Unit) {
        if(busy) return
        val epoch=generation
        busy=true; error=null
        scope.launch {
            try { block(); if(epoch==generation) onSuccess() }
            catch(e: CancellationException) { throw e }
            catch(e: Exception) { if(epoch==generation) handle(e) }
            finally { if(epoch==generation) busy=false }
        }
    }
    private fun handle(e: Exception) {
        error=failureCode(e)
        if(repository?.session == null && user != null) clearAccount()
    }
    private fun clearAccount() {
        user=null; needsProfile=false; passwordRecovery=false; connected=false
        tasks.clear(); applications.clear(); reviews.clear(); friends.clear(); conversations.clear()
        messages.clear(); activeChat=null; rating=null; completedCount=0
    }
    private fun sessionUser() {
        val session=repo().session ?: return
        user=User(session.userId,session.name,session.email,session.publicId)
        requestedId=session.requestedId; needsProfile=session.publicId.isBlank()
    }
    private suspend fun hydrate() {
        val epoch=generation
        val snapshot=repo().snapshot()
        if(epoch!=generation) return
        if(snapshot.user!=null) user=snapshot.user else sessionUser()
        needsProfile=snapshot.user==null
        tasks.clear(); tasks.addAll(snapshot.tasks)
        applications.clear(); applications.addAll(snapshot.applications)
        reviews.clear(); reviews.addAll(snapshot.reviews)
        friends.clear(); friends.addAll(snapshot.friends)
        conversations.clear(); conversations.addAll(snapshot.conversations)
        rating=snapshot.rating; completedCount=snapshot.completedCount; connected=true
    }
    suspend fun refreshQuietly() {
        if(snapshotLoading || busy || user==null || needsProfile || passwordRecovery) return
        snapshotLoading=true
        try { hydrate() } catch(e: CancellationException) { throw e }
        catch(e: Exception) { connected=false; if(repository?.session==null) handle(e) }
        finally { snapshotLoading=false }
    }
    fun refresh()=action { hydrate() }
    fun login(email: String,password: String)=action {
        repo().login(email,password); sessionUser(); hydrate()
    }
    fun signup(name: String,email: String,password: String,id: String,onEmailRequired: () -> Unit)=action {
        if(!InputRules.validName(name)) throw ApiFailure(0,"INVALID_NAME","")
        if(!InputRules.validPublicId(id,true)) throw ApiFailure(0,"INVALID_ID","")
        if(!InputRules.validPassword(password)) throw ApiFailure(0,"WEAK_PASSWORD","")
        if(repo().signup(name,email,password,id)) { sessionUser(); hydrate() } else onEmailRequired()
    }
    fun verify(email: String,code: String,recovery: Boolean)=action {
        repo().verify(email,code,recovery); sessionUser()
        passwordRecovery=recovery
        if(!recovery) hydrate()
    }
    fun resend(email: String)=action { repo().resend(email); notice="CODE_SENT" }
    fun recover(email: String,onSent: () -> Unit)=action(onSent) { repo().recover(email) }
    fun changePassword(password: String)=action {
        if(!InputRules.validPassword(password)) throw ApiFailure(0,"WEAK_PASSWORD","")
        repo().changePassword(password); passwordRecovery=false; hydrate()
    }
    fun finishProfile(name: String,id: String)=action {
        if(!InputRules.validName(name)) throw ApiFailure(0,"INVALID_NAME","")
        if(!InputRules.validPublicId(id,true)) throw ApiFailure(0,"INVALID_ID","")
        repo().rpc("finish_profile",JSONObject().put("p_name",name.trim()).put("p_id",id.ifBlank { null }))
        hydrate()
    }
    fun updateName(name: String,onSaved: () -> Unit)=action(onSaved) {
        if(!InputRules.validName(name)) throw ApiFailure(0,"INVALID_NAME","")
        repo().rpc("rename",JSONObject().put("p_name",name.trim())); hydrate()
    }
    fun create(title: String,description: String,category: Category,area: String,date: String,slots: Int,key: String,onCreated: () -> Unit)=action(onCreated) {
        val instant=LocalDateTime.parse(date).atZone(ZoneId.systemDefault()).toInstant()
        repo().rpc("create_task",JSONObject().put("p_title",title).put("p_description",description).put("p_category",category.name)
            .put("p_area",area).put("p_date",instant.toString()).put("p_slots",slots).put("p_key",key))
        hydrate()
    }
    fun accepted(taskId: Long)=tasks.firstOrNull { it.id==taskId }?.confirmed ?: 0
    fun apply(task: HelpTask,onApplied: () -> Unit)=action(onApplied) {
        repo().rpc("apply_task",JSONObject().put("p_task",task.id)); hydrate()
    }
    fun decide(application: Application,accept: Boolean)=action {
        repo().rpc("decide_application",JSONObject().put("p_application",application.id).put("p_accept",accept)); hydrate()
    }
    fun complete(task: HelpTask)=action {
        repo().rpc("complete_task",JSONObject().put("p_task",task.id)); hydrate()
    }
    fun review(taskId: Long,recipientId: String,rating: Int,text: String)=action {
        repo().rpc("review",JSONObject().put("p_task",taskId).put("p_recipient",recipientId).put("p_rating",rating).put("p_body",text)); hydrate()
    }
    fun invite(id: String,onSent: () -> Unit)=action(onSent) {
        if(!InputRules.validPublicId(id)) throw ApiFailure(0,"INVALID_ID","")
        repo().rpc("invite_friend",JSONObject().put("p_id",id)); hydrate()
    }
    fun decideFriend(request: FriendRequest,accept: Boolean)=action {
        repo().rpc("decide_friend",JSONObject().put("p_request",request.id).put("p_accept",accept)); hydrate()
    }
    fun openChat(peerId: String,taskId: Long? = null)=action {
        val id=repo().rpc("open_chat",JSONObject().put("p_peer",peerId).put("p_task",taskId)).trim().toLong()
        hydrate(); showChat(id)
    }
    fun showChat(id: Long) {
        activeChat=id; messages.clear(); chatError=null; chatLoaded=false; hasOlderMessages=false
    }
    fun closeChat() { activeChat=null; messages.clear(); chatLoaded=false; chatError=null }
    suspend fun refreshMessages() {
        val id=activeChat ?: return
        if(chatLoading) return
        val epoch=generation
        chatLoading=true
        try {
            val page=repo().messages(id,after=if(chatLoaded) messages.maxOfOrNull { it.id } else null)
            if(activeChat!=id || epoch!=generation) return
            if(!chatLoaded) hasOlderMessages=page.size==50
            messages.addAll(page.filter { next -> messages.none { it.id==next.id } })
            messages.sortBy { it.id }; chatLoaded=true; chatError=null
        } catch(e: CancellationException) { throw e }
        catch(e: Exception) { if(activeChat==id && epoch==generation) chatError=failureCode(e) }
        finally { chatLoading=false }
    }
    fun olderMessages()=action {
        val id=activeChat ?: return@action
        val page=repo().messages(id,before=messages.minOfOrNull { it.id })
        if(activeChat==id) {
            messages.addAll(page.filter { next -> messages.none { it.id==next.id } })
            messages.sortBy { it.id }; hasOlderMessages=page.size==50
        }
    }
    fun sendMessage(body: String,key: String,onSent: () -> Unit)=action(onSent) {
        val id=activeChat ?: throw ApiFailure(0,"NOT_FOUND","")
        if(!InputRules.validMessage(body)) throw ApiFailure(0,"INVALID_MESSAGE","")
        repo().rpc("send_message",JSONObject().put("p_chat",id).put("p_body",body).put("p_key",key))
        refreshMessages()
    }
    fun signOut() {
        generation++; scope.coroutineContext.cancelChildren(); busy=true; error=null
        scope.launch {
            try {
                val revoked=repo().logout()
                clearAccount()
                if(!revoked) notice="LOCAL_SIGNOUT"
            } catch(e: Exception) { error=failureCode(e) }
            finally { busy=false }
        }
    }
    override fun onCleared() { scope.cancel() }
}

private fun failureCode(e: Exception): String {
    if(e !is ApiFailure) return when(e) {
        is java.net.SocketTimeoutException -> "NETWORK_TIMEOUT"
        is java.net.UnknownHostException -> "NETWORK_DNS"
        is javax.net.ssl.SSLException -> "NETWORK_TLS"
        is java.net.ConnectException -> "NETWORK_CONNECT"
        is java.io.IOException -> "NETWORK"
        else -> "SERVER"
    }
    val known=listOf("AUTH_REQUIRED","INVALID_NAME","INVALID_ID","ID_TAKEN","ID_RETRY","PROFILE_REQUIRED","INVALID_DATE",
        "NOT_FOUND","OWN_TASK","TASK_CLOSED","TASK_FULL","FORBIDDEN","ACCEPT_FIRST","PERSON_NOT_FOUND","SELF_INVITE",
        "RATE_LIMIT","INVITE_DECLINED","INVALID_MESSAGE","NOT_CONFIGURED","WEAK_PASSWORD")
    known.firstOrNull { it==e.errorCode || e.serverMessage.contains(it) }?.let { return it }
    return when {
        e.errorCode=="email_not_confirmed" -> "VERIFY_EMAIL"
        e.errorCode=="invalid_credentials" -> "AUTH_FAILED"
        e.errorCode=="weak_password" -> "WEAK_PASSWORD"
        e.errorCode=="otp_expired" -> "BAD_CODE"
        e.errorCode=="email_address_not_authorized" -> "EMAIL_NOT_AUTHORIZED"
        e.errorCode=="over_email_send_rate_limit" -> "RATE_LIMIT"
        e.errorCode=="email_address_invalid" -> "INVALID_EMAIL"
        e.errorCode=="user_already_exists" -> "ACCOUNT_EXISTS"
        e.status>=500 && (e.serverMessage.contains("sending",true) || e.serverMessage.contains("SMTP",true)) -> "SMTP_FAILED"
        e.status==429 -> "RATE_LIMIT"
        e.status==401 || e.status==403 -> "AUTH_REQUIRED"
        e.errorCode.startsWith("PGRST") -> "SERVER_SETUP"
        else -> "SERVER"
    }
}

