package com.asar.app.network

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class AuthSession(
    val access: String, val refresh: String, val expiresAt: Long, val userId: String, val email: String,
    val name: String = "", val publicId: String = "", val requestedId: String = ""
) {
    fun json() = JSONObject().put("access",access).put("refresh",refresh).put("expires",expiresAt)
        .put("user_id",userId).put("email",email).put("name",name).put("public_id",publicId).put("requested_id",requestedId)
    companion object {
        fun stored(json: JSONObject) = AuthSession(json.getString("access"),json.getString("refresh"),
            json.getLong("expires"),json.getString("user_id"),json.getString("email"),
            json.optString("name"),json.optString("public_id"),json.optString("requested_id"))
        fun response(json: JSONObject, previous: AuthSession? = null): AuthSession {
            val user = json.getJSONObject("user")
            val metadata = user.optJSONObject("user_metadata") ?: JSONObject()
            return AuthSession(json.getString("access_token"),json.getString("refresh_token"),
                json.optLong("expires_at",System.currentTimeMillis()/1000+json.optLong("expires_in",3600)),
                user.getString("id"),user.optString("email"),
                previous?.name ?: metadata.optString("full_name"),
                previous?.publicId.orEmpty(), previous?.requestedId ?: metadata.optString("public_id"))
        }
    }
}

/** Tokens are encrypted with a non-exportable Android Keystore key; no password is saved. */
class SessionStore(context: Context) {
    private val file = AtomicFile(File(context.noBackupFilesDir,"asar-session-v1"))
    private val alias = "asar.session.v1"
    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias,null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    @Synchronized fun read(): AuthSession? {
        if(!file.baseFile.exists()) return null
        return try {
            val parts = file.openRead().bufferedReader().use { it.readText() }.split(".")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)))
            AuthSession.stored(JSONObject(String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),Charsets.UTF_8)))
        } catch (_: Exception) { file.delete(); null }
    }
    @Synchronized fun write(session: AuthSession) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE,key()) }
        val encrypted = Base64.encodeToString(cipher.iv,Base64.NO_WRAP)+"."+
            Base64.encodeToString(cipher.doFinal(session.json().toString().toByteArray(Charsets.UTF_8)),Base64.NO_WRAP)
        val stream = file.startWrite()
        try { stream.write(encrypted.toByteArray(Charsets.UTF_8)); file.finishWrite(stream) }
        catch(e: Exception) { file.failWrite(stream); throw e }
    }
    @Synchronized fun clear() { file.delete() }
}

