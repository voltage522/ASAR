package com.asar.app.data

enum class Role { Volunteer, Requester }
enum class Category { All, Community, Environment, Essentials, Education, Moving }
enum class ApplicationStatus { Pending, Accepted, Rejected, Completed }
data class User(val id: String, val name: String, val email: String, val publicId: String = "")
data class HelpTask(
    val id: Long, val title: String, val description: String, val category: Category,
    val area: String, val date: String, val slots: Int, val requester: String,
    val ownerId: String, val owned: Boolean = false, val skills: List<String> = emptyList(),
    val completed: Boolean = false, val confirmed: Int = 0
)
data class Application(val id: Long, val taskId: Long, val name: String, val mine: Boolean,
    val volunteerId: String, val status: ApplicationStatus)
data class Review(val id: Long, val taskId: Long, val recipientId: String, val rating: Int, val text: String)
data class FriendRequest(val id: Long, val peerId: String, val peerName: String, val publicId: String,
    val incoming: Boolean, val status: String)
data class Conversation(val id: Long, val peerId: String, val peerName: String, val title: String, val lastMessage: String)
data class ChatMessage(val id: Long, val chatId: Long, val senderId: String, val body: String, val createdAt: String, val clientKey: String)
data class Snapshot(val user: User?, val tasks: List<HelpTask>, val applications: List<Application>,
    val reviews: List<Review>, val friends: List<FriendRequest>, val conversations: List<Conversation>,
    val rating: Double?, val completedCount: Int)

