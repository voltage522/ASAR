package com.asar.app.data

enum class Language(val tag: String, val label: String) {
    Russian("ru", "Русский"), Kazakh("kk", "Қазақша"), English("en", "English")
}

