package com.asar.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.asar.app.data.*
import com.asar.app.ui.LocalStrings
import com.asar.app.ui.components.*
import com.asar.app.ui.screens.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AsarApp(state: AsarState) {
    val s = LocalStrings.current
    if(state.restoring) {
        Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { CircularProgressIndicator() }
        return
    }
    if(state.user == null) { WelcomeScreen(state); return }
    if(state.needsProfile || state.passwordRecovery) { CompleteAccountScreen(state); return }
    key(state.user!!.id) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var selectedTask by rememberSaveable { mutableStateOf<Long?>(null) }
        var roleMenu by remember { mutableStateOf(false) }
        val pages = rememberSaveableStateHolder()
        val snackbar = remember { SnackbarHostState() }
        val scope = rememberCoroutineScope()
        val lifecycle = LocalLifecycleOwner.current.lifecycle
        LaunchedEffect(lifecycle) {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while(isActive) { state.refreshQuietly(); delay(20000) }
            }
        }
        LaunchedEffect(state.error, state.notice) {
            val failure=state.error
            val notice=state.notice
            if(failure!=null) { snackbar.showSnackbar(s.failure(failure)); if(state.error==failure) state.error=null }
            if(notice!=null) { snackbar.showSnackbar(s.failure(notice)); if(state.notice==notice) state.notice=null }
        }
        BackHandler(enabled = state.activeChat!=null || selectedTask != null || tab != 0) {
            when { state.activeChat!=null -> state.closeChat(); selectedTask!=null -> selectedTask=null; else -> tab=0 }
        }
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbar) },
            topBar = {
                TopAppBar(
                    title = { AsarBrand() },
                    actions = {
                        Box(Modifier.padding(end=12.dp)) {
                            FilledTonalButton(onClick={roleMenu=true}) { Text(s.role(state.role)) }
                            DropdownMenu(roleMenu,{roleMenu=false}) {
                                Role.entries.forEach { role ->
                                    DropdownMenuItem(text={Text(s.role(role))},
                                        leadingIcon={RadioButton(state.role==role,onClick=null)},
                                        onClick={state.role=role;roleMenu=false})
                                }
                            }
                        }
                    },
                    colors=TopAppBarDefaults.topAppBarColors(containerColor=MaterialTheme.colorScheme.background)
                )
            },
            bottomBar = {
                if(state.activeChat==null) NavigationBar(containerColor=MaterialTheme.colorScheme.surfaceContainer) {
                    listOf(R.string.home,R.string.my_tasks,R.string.create,R.string.messages,R.string.profile).forEachIndexed { index,label ->
                        NavigationBarItem(selected=tab==index,
                            onClick={tab=index;selectedTask=null},
                            icon={NavGlyph(listOf(0,1,2,5,3)[index],if(tab==index) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)},
                            label={Text(s(label),maxLines=1)},alwaysShowLabel=true)
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if(state.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                if(!state.connected) Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(s(R.string.offline),modifier=Modifier.weight(1f),style=MaterialTheme.typography.bodySmall)
                    TextButton(enabled=!state.busy,onClick={state.refresh()}) {Text(s(R.string.retry))}
                }
                Box(Modifier.weight(1f)) {
                    val task=state.tasks.firstOrNull {it.id==selectedTask}
                    if(state.activeChat!=null) ChatScreen(state)
                    else if(task!=null) pages.SaveableStateProvider("task_${task.id}") {
                        TaskDetailsScreen(state,task,onBack={selectedTask=null},notify={scope.launch {snackbar.showSnackbar(it)}})
                    } else pages.SaveableStateProvider("page_$tab") {
                        when(tab) {
                            0 -> HomeScreen(state){selectedTask=it}
                            1 -> MyTasksScreen(state){selectedTask=it}
                            2 -> CreateScreen(state) {
                                pages.removeState("page_2");tab=0
                                scope.launch {snackbar.showSnackbar(s(R.string.published))}
                            }
                            3 -> MessagesScreen(state)
                            else -> ProfileScreen(state)
                        }
                    }
                }
            }
        }
    }
}
