package com.asar.app.ui.theme

import androidx.compose.material3.Typography

// Material 3 type scale, with the device font and support for enlarged system text.
val Typography = Typography()

