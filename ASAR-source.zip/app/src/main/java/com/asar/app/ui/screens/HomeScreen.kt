package com.asar.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.asar.app.R
import com.asar.app.data.*
import com.asar.app.ui.LocalStrings
import com.asar.app.ui.components.*

@Composable
fun HomeScreen(state: AsarState, openTask: (Long) -> Unit) {
    val s = LocalStrings.current
    var query by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf(Category.All) }
    val filtered = state.tasks.filter { task ->
        val display = s.task(task)
        (category == Category.All || task.category == category) &&
            (display.title + " " + display.area + " " + display.description + " " + task.title + " " + task.area)
                .contains(query.trim(), ignoreCase = true)
    }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            PageHeading(s(R.string.greeting, state.user!!.name.substringBefore(' ')), s(R.string.home_subtitle))
        }
        item {
            OutlinedTextField(query, { query = it }, placeholder = { Text(s(R.string.search)) },
                leadingIcon = { NavGlyph(4, MaterialTheme.colorScheme.onSurfaceVariant) },
                singleLine = true, shape = MaterialTheme.shapes.extraLarge, modifier = Modifier.fillMaxWidth())
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                shape = MaterialTheme.shapes.extraLarge) {
                Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(s(R.string.home_banner), style = MaterialTheme.typography.titleLarge)
                    Text(s(R.string.home_banner_body), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Category.entries.forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(s.category(c)) }) }
            }
        }
        item {
            Text(s(R.string.requests_title), style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(s(R.string.request_count, filtered.size) + " · " + s(R.string.real_requests),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if(filtered.isEmpty()) item {
            InfoPanel(s(if(state.tasks.isEmpty()) R.string.home_empty else R.string.no_results), s(if(state.tasks.isEmpty()) R.string.home_empty_body else R.string.search_hint)) {
                TextButton(onClick = { query = ""; category = Category.All }) { Text(s(R.string.clear_filters)) }
            }
        }
        items(filtered, key = { it.id }) { task -> TaskCard(task, state.accepted(task.id)) { openTask(task.id) } }
    }
}

