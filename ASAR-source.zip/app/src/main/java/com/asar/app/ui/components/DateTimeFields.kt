package com.asar.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.asar.app.R
import com.asar.app.ui.LocalStrings
import java.time.*
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateTimeFields(date: String, time: String, onDate: (String) -> Unit, onTime: (String) -> Unit) {
    val s = LocalStrings.current
    var calendar by remember { mutableStateOf(false) }
    var clock by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(onClick = { calendar = true }, modifier = Modifier.weight(1f).heightIn(min = 64.dp), shape = MaterialTheme.shapes.medium) {
            Column {
                Text(s(R.string.date), style = MaterialTheme.typography.labelSmall)
                Text(LocalDate.parse(date).format(DateTimeFormatter.ofPattern("d MMM yyyy", s.locale)))
            }
        }
        OutlinedButton(onClick = { clock = true }, modifier = Modifier.weight(1f).heightIn(min = 64.dp), shape = MaterialTheme.shapes.medium) {
            Column {
                Text(s(R.string.time), style = MaterialTheme.typography.labelSmall)
                Text(time)
            }
        }
    }
    if(calendar) {
        val startOfToday = LocalDate.now().atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli()
        val picker = rememberDatePickerState(
            initialSelectedDateMillis = LocalDate.parse(date).atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli(),
            selectableDates = object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long) = utcTimeMillis >= startOfToday
            }
        )
        DatePickerDialog(
            onDismissRequest = { calendar = false },
            confirmButton = {
                TextButton(enabled = picker.selectedDateMillis != null, onClick = {
                    picker.selectedDateMillis?.let { onDate(Instant.ofEpochMilli(it).atOffset(ZoneOffset.UTC).toLocalDate().toString()) }
                    calendar = false
                }) { Text(s(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { calendar = false }) { Text(s(R.string.cancel)) } }
        ) {
            DatePicker(state = picker, title = { Text(s(R.string.choose_date), Modifier.padding(start = 24.dp, top = 16.dp)) })
        }
    }
    if(clock) {
        val initial = LocalTime.parse(time)
        val picker = rememberTimePickerState(initialHour = initial.hour, initialMinute = initial.minute, is24Hour = true)
        AlertDialog(
            onDismissRequest = { clock = false },
            title = { Text(s(R.string.choose_time)) },
            text = { TimeInput(state = picker) },
            confirmButton = {
                TextButton(onClick = {
                    onTime(LocalTime.of(picker.hour, picker.minute).format(DateTimeFormatter.ofPattern("HH:mm")))
                    clock = false
                }) { Text(s(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { clock = false }) { Text(s(R.string.cancel)) } }
        )
    }
}

