package com.asar.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.asar.app.R
import com.asar.app.data.*
import com.asar.app.ui.LocalStrings
import com.asar.app.ui.components.*

@Composable
fun MyTasksScreen(state: AsarState, openTask: (Long) -> Unit) {
    val s = LocalStrings.current
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { PageHeading(s(R.string.my_tasks), s(if(state.role == Role.Volunteer) R.string.my_volunteer_subtitle else R.string.my_requester_subtitle)) }
        if(state.role == Role.Volunteer) {
            val mine = state.applications.filter { it.mine }
            if(mine.isEmpty()) item { InfoPanel(s(R.string.no_my_applications), s(R.string.no_my_applications_hint)) }
            items(mine, key = { it.id }) { application ->
                val task = s.task(state.tasks.firstOrNull { it.id == application.taskId } ?: return@items)
                InfoPanel(task.title, s.status(application.status)) {
                    Text(task.area + " · " + task.date, style = MaterialTheme.typography.bodySmall)
                    FilledTonalButton(onClick = { openTask(task.id) }) { Text(s(R.string.view_request)) }
                }
            }
        } else {
            val owned = state.tasks.filter { it.owned }
            if(owned.isEmpty()) item { InfoPanel(s(R.string.no_my_requests), s(R.string.no_my_requests_hint)) }
            items(owned, key = { it.id }) { task ->
                TaskCard(task, state.accepted(task.id)) { openTask(task.id) }
                val pending = state.applications.count { it.taskId == task.id && it.status == ApplicationStatus.Pending }
                if(pending > 0) TextButton(onClick = { openTask(task.id) }) { Text(s(R.string.pending_count, pending)) }
            }
        }
    }
}

