package com.asar.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.asar.app.R
import com.asar.app.data.*
import com.asar.app.ui.LocalStrings
import com.asar.app.ui.components.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(state: AsarState) {
    val s=LocalStrings.current
    val user=state.user ?: return
    val clipboard=LocalClipboardManager.current
    val context=LocalContext.current
    var editingName by rememberSaveable {mutableStateOf(false)}
    var nameDraft by rememberSaveable {mutableStateOf("")}
    var inviteId by rememberSaveable {mutableStateOf("")}
    var leaving by remember {mutableStateOf(false)}
    if(editingName) AlertDialog(
        onDismissRequest={if(!state.busy) editingName=false},
        title={Text(s(R.string.edit_name))},
        text={NameField(nameDraft,{nameDraft=it})},
        confirmButton={TextButton(enabled=!state.busy,onClick={state.updateName(nameDraft){editingName=false}}){Text(s(R.string.save))}},
        dismissButton={TextButton(enabled=!state.busy,onClick={editingName=false}){Text(s(R.string.cancel))}}
    )
    if(leaving) AlertDialog(
        onDismissRequest={leaving=false},title={Text(s(R.string.logout_title))},text={Text(s(R.string.logout_body))},
        confirmButton={TextButton(onClick={leaving=false;state.signOut()}){Text(s(R.string.logout))}},
        dismissButton={TextButton(onClick={leaving=false}){Text(s(R.string.cancel))}}
    )
    Column(Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement=Arrangement.spacedBy(20.dp)) {
        PageHeading(s(R.string.profile))
        Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer),shape=MaterialTheme.shapes.extraLarge) {
            Column(Modifier.fillMaxWidth().padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(16.dp)) {
                    Surface(shape=CircleShape,color=MaterialTheme.colorScheme.surfaceContainerLowest,modifier=Modifier.size(64.dp)) {
                        Box(contentAlignment=Alignment.Center){Text(user.name.take(1).uppercase(),style=MaterialTheme.typography.headlineMedium)}
                    }
                    Column(Modifier.weight(1f)) {
                        Text(user.name,style=MaterialTheme.typography.titleLarge)
                        Text(user.email,style=MaterialTheme.typography.bodySmall)
                    }
                }
                Text(s(R.string.my_id,user.publicId),style=MaterialTheme.typography.titleMedium)
                FlowRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick={clipboard.setText(AnnotatedString(user.publicId));state.notice="ID_COPIED"}){Text(s(R.string.copy_id))}
                    TextButton(onClick={
                        val intent=Intent(Intent.ACTION_SEND).apply {type="text/plain";putExtra(Intent.EXTRA_TEXT,s(R.string.invite_share,user.name,user.publicId))}
                        context.startActivity(Intent.createChooser(intent,s(R.string.share_id)))
                    }){Text(s(R.string.share_id))}
                    TextButton(onClick={nameDraft=user.name;editingName=true}){Text(s(R.string.edit_name))}
                }
                Pill(s(R.string.email_verified))
            }
        }
        LanguagePicker(state)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            MetricCard(state.rating?.let {String.format(s.locale,"%.1f ★",it)} ?: "—",
                s(if(state.rating==null) R.string.no_rating else R.string.rating),Modifier.weight(1f))
            MetricCard("${state.completedCount}",s(R.string.completed_count),Modifier.weight(1f))
        }
        Text(s(R.string.friends),style=MaterialTheme.typography.titleLarge)
        OutlinedTextField(inviteId,{inviteId=it},label={Text(s(R.string.friend_id))},singleLine=true,
            keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),modifier=Modifier.fillMaxWidth())
        FilledTonalButton(onClick={state.invite(inviteId){inviteId="";state.notice="INVITE_SENT"}},enabled=!state.busy) {Text(s(R.string.invite_friend))}
        if(state.friends.isEmpty()) Text(s(R.string.no_friends),color=MaterialTheme.colorScheme.onSurfaceVariant)
        state.friends.forEach {friend->
            InfoPanel(friend.peerName+" · "+friend.publicId,s(when(friend.status) {
                "Accepted" -> R.string.friend_accepted
                "Rejected" -> R.string.friend_rejected
                else -> if(friend.incoming) R.string.incoming_invite else R.string.outgoing_invite
            })) {
                if(friend.status=="Pending" && friend.incoming) FlowRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Button(onClick={state.decideFriend(friend,true)},enabled=!state.busy){Text(s(R.string.accept))}
                    OutlinedButton(onClick={state.decideFriend(friend,false)},enabled=!state.busy){Text(s(R.string.reject))}
                }
                if(friend.status=="Accepted") FilledTonalButton(onClick={state.openChat(friend.peerId)},enabled=!state.busy){Text(s(R.string.write_message))}
            }
        }
        Text(s(R.string.history),style=MaterialTheme.typography.titleLarge)
        val completed=state.applications.filter {it.mine && it.status==ApplicationStatus.Completed}
        if(completed.isEmpty()) Text(s(R.string.history_empty),color=MaterialTheme.colorScheme.onSurfaceVariant)
        completed.forEach {a->state.tasks.firstOrNull {it.id==a.taskId}?.let {task->
            InfoPanel(task.title,s(R.string.completed)) {
                state.reviews.firstOrNull {it.taskId==task.id && it.recipientId==user.id}?.let {Text("★".repeat(it.rating)+" · "+it.text)}
            }
        }}
        OutlinedButton(onClick={leaving=true},enabled=!state.busy,modifier=Modifier.fillMaxWidth()){Text(s(R.string.logout))}
    }
}
@Composable
private fun MetricCard(value: String,caption: String,modifier: Modifier) {
    Card(modifier,colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text(value,style=MaterialTheme.typography.headlineSmall)
            Text(caption,style=MaterialTheme.typography.bodySmall)
        }
    }
}

