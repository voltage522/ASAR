package com.asar.app.ui.theme

import androidx.compose.ui.graphics.Color

val AccentBlue = Color(0xFF2864E8)
val SoftBlue = Color(0xFFDCEAFE)
val AppBackground = Color(0xFFF5F8FC)
val Mint = Color(0xFFBDE8D7)
val Ink = Color(0xFF202938)
val Muted = Color(0xFF6B7280)
