package com.asar.app.data

data class Suggestion(val category: Category, val difficulty: String, val volunteers: Int, val skills: List<String>)
object TaskAnalyzer {
    fun analyze(text: String): Suggestion {
        val input = text.lowercase()
        return when {
            listOf("piano", "furniture", "moving", "boxes", "carry", "переезд", "короб", "мебел", "перенести", "көшу", "жиһаз", "қорап", "тасу").any { it in input } ->
                Suggestion(Category.Moving, "High · assess lifting safety", 4, listOf("Teamwork", "Safe lifting"))
            listOf("park", "tree", "litter", "clean", "garden", "парк", "мусор", "дерев", "убор", "убрать", "қоқыс", "саябақ", "ағаш", "тазала").any { it in input } ->
                Suggestion(Category.Environment, "Moderate", 6, listOf("Outdoor work", "Teamwork"))
            listOf("teach", "english", "student", "tutor", "учить", "англий", "школь", "обуч", "үйрет", "оқушы", "ағылшын", "қазақша").any { it in input } ->
                Suggestion(Category.Education, "Moderate", 2, listOf("Mentoring", "Communication"))
            listOf("grocer", "food", "elder", "shopping", "продукт", "пожил", "покуп", "обед", "азық", "қарт", "тамақ").any { it in input } ->
                Suggestion(Category.Essentials, "Light", 2, listOf("Communication", "Organisation"))
            else -> Suggestion(Category.Community, "Light", 3, listOf("Teamwork", "Communication"))
        }
    }
    fun needsVerification(text: String): Boolean {
        val input = text.lowercase()
        val heavy = Regex("""(\d+)\s*(kg|kilograms?|кг|килограмм|килограм)""").findAll(input)
            .any { (it.groupValues[1].toIntOrNull() ?: 0) >= 100 }
        val alone = listOf("alone", "one volunteer", "single", "один", "одна", "в одиночку", "жалғыз", "бір ерікті")
            .any { it in input }
        val piano = listOf("piano", "пианино", "рояль").any { it in input }
        return alone && (heavy || piano)
    }
    fun verify(text: String): String = if(needsVerification(text))
        "Additional verification suggested. Confirm the load, equipment and people involved. This is not a fraud determination."
    else "No rule-based concern detected. This does not verify that the event happened."
}

