package com.asar.app.network

import com.asar.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.io.IOException

class ApiFailure(val status: Int, val errorCode: String, val serverMessage: String) : IOException(errorCode)

class SupabaseApi {
    private val base = BuildConfig.SUPABASE_URL.trim().trimEnd('/')
    private val key = BuildConfig.SUPABASE_PUBLISHABLE_KEY.trim()
    val configured: Boolean get() = runCatching {
        val uri = URI(base)
        uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null &&
            uri.query == null && uri.fragment == null && key.isNotBlank() &&
            !key.startsWith("sb_secret_") && !isServiceRole(key)
    }.getOrDefault(false)

    private fun isServiceRole(value: String): Boolean = runCatching {
        val part = value.split('.').getOrNull(1) ?: return false
        val payload = String(android.util.Base64.decode(part,android.util.Base64.URL_SAFE),Charsets.UTF_8)
        JSONObject(payload).optString("role") == "service_role"
    }.getOrDefault(false)

    suspend fun request(path: String, method: String = "GET", body: JSONObject? = null, token: String? = null): String =
        withContext(Dispatchers.IO) {
            if(!configured) throw ApiFailure(0,"NOT_CONFIGURED","")
            val connection = URL(base+path).openConnection() as HttpURLConnection
            try {
                connection.requestMethod = method
                connection.connectTimeout = 15000
                // Auth may wait for the configured SMTP provider before replying.
                connection.readTimeout = if(path.startsWith("/auth/")) 60000 else 20000
                connection.instanceFollowRedirects = false
                connection.setRequestProperty("apikey",key)
                connection.setRequestProperty("Accept","application/json")
                token?.let { connection.setRequestProperty("Authorization","Bearer $it") }
                if(body != null) {
                    connection.doOutput = true
                    connection.setRequestProperty("Content-Type","application/json; charset=utf-8")
                    connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                }
                val status = connection.responseCode
                val stream = if(status in 200..299) connection.inputStream else connection.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if(status !in 200..299) {
                    val error = runCatching { JSONObject(text) }.getOrDefault(JSONObject())
                    throw ApiFailure(status,error.optString("error_code",error.optString("code")),
                        error.optString("msg",error.optString("message",error.optString("error_description"))))
                }
                text
            } catch(e: IOException) {
                if(BuildConfig.DEBUG) {
                    val kind=if(e is ApiFailure) "HTTP ${e.status} ${e.errorCode}" else e.javaClass.simpleName
                    android.util.Log.w("AsarNetwork","$method ${path.substringBefore('?')}: $kind")
                }
                throw e
            } finally { connection.disconnect() }
        }
}

