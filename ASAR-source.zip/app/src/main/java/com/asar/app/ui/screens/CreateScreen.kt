package com.asar.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.asar.app.R
import com.asar.app.data.*
import com.asar.app.ui.LocalStrings
import com.asar.app.ui.components.*
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun CreateScreen(state: AsarState, onCreated: () -> Unit) {
    val s = LocalStrings.current
    var title by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var area by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf(Category.Community) }
    var slots by rememberSaveable { mutableIntStateOf(3) }
    var date by rememberSaveable { mutableStateOf(LocalDate.now().plusDays(1).toString()) }
    var time by rememberSaveable { mutableStateOf("10:00") }
    var error by rememberSaveable { mutableStateOf<Int?>(null) }
    var showAnalysis by rememberSaveable { mutableStateOf(false) }
    val requestKey = rememberSaveable { java.util.UUID.randomUUID().toString() }
    Column(Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)) {
        PageHeading(s(R.string.create_title), s(R.string.create_subtitle))
        if(state.role != Role.Requester) InfoPanel(s(R.string.volunteer_mode), s(R.string.switch_create_hint)) {
            TextButton(onClick = { state.role = Role.Requester }) { Text(s(R.string.switch_requester)) }
        }
        OutlinedTextField(title, { title = it; error = null }, label = { Text(s(R.string.task_title)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(description, { description = it; error = null }, label = { Text(s(R.string.task_description)) }, minLines = 4, modifier = Modifier.fillMaxWidth())
        InfoPanel(s(R.string.analyzer_title), s(R.string.analyzer_note)) {
            TextButton(enabled = title.isNotBlank() || description.isNotBlank(), onClick = { showAnalysis = true }) { Text(s(R.string.analyze)) }
            if(showAnalysis) {
                val suggestion = TaskAnalyzer.analyze(title + " " + description)
                Text(s.category(suggestion.category) + " · " + s.difficulty(suggestion.difficulty), style = MaterialTheme.typography.titleSmall)
                Text(s(R.string.suggestion_team, suggestion.volunteers), style = MaterialTheme.typography.bodyMedium)
                Text(suggestion.skills.joinToString(" · ") { s.skill(it) }, style = MaterialTheme.typography.bodyMedium)
                FilledTonalButton(onClick = { category = suggestion.category; slots = suggestion.volunteers }) { Text(s(R.string.use_suggestion)) }
            }
        }
        Column {
            Text(s(R.string.category), style = MaterialTheme.typography.titleMedium)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Category.entries.filter { it != Category.All }.forEach { c ->
                    FilterChip(category == c, { category = c }, label = { Text(s.category(c)) })
                }
            }
        }
        OutlinedTextField(area, { area = it; error = null }, label = { Text(s(R.string.area)) }, singleLine = true,
            supportingText = { Text(s(R.string.location_note)) }, modifier = Modifier.fillMaxWidth())
        DateTimeFields(date, time, onDate = { date = it; error = null }, onTime = { time = it; error = null })
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
            Column(Modifier.padding(20.dp)) {
                Text(s(R.string.volunteers_count), style = MaterialTheme.typography.titleMedium)
                Text(s(R.string.people_count, slots), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                Slider(value = slots.toFloat(), onValueChange = { slots = it.toInt() }, valueRange = 1f..20f, steps = 18)
            }
        }
        error?.let { Text(s(it), color = MaterialTheme.colorScheme.error) }
        PrimaryButton(s(R.string.publish), enabled = state.role == Role.Requester && !state.busy) {
            error = when {
                title.trim().length !in 5..120 -> R.string.title_error
                description.trim().length !in 15..5000 -> R.string.description_error
                area.trim().length !in 1..160 -> R.string.area_error
                java.time.LocalDateTime.of(LocalDate.parse(date), LocalTime.parse(time)).isBefore(java.time.LocalDateTime.now()) -> R.string.date_error
                else -> null
            }
            if(error == null) {
                state.create(title, description, category, area, date + "T" + time, slots, requestKey, onCreated)
            }
        }
    }
}

