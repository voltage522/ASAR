package com.asar.app.data

object InputRules {
    fun validName(value: String) = value.trim().length in 1..50
    fun validPublicId(value: String, optional: Boolean = false) =
        (optional && value.isBlank()) || Regex("^[0-9]{8}$").matches(value)
    fun validMessage(value: String) = value.trim().length in 1..4000
    fun validPassword(value: String) = value.length >= 8
}

