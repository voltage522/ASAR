package com.asar.app

import com.asar.app.data.*
import org.junit.Assert.*
import org.junit.Test

class AsarFlowTest {
    @Test fun namesSupportKazakhRussianAndHyphens() {
        listOf("Әлия Қуанышқызы","Сергей Ёлкин","Нұрсұлтан Әбдіғалиұлы","Ә Ғ Қ Ң Ө Ұ Ү Һ І","Анна-Мария").forEach {
            assertTrue(InputRules.validName(it))
            assertEquals(it,User("uuid",it,"mail@example.com").name)
        }
        assertFalse(InputRules.validName("   "))
        assertFalse(InputRules.validName("A".repeat(51)))
    }
    @Test fun publicIdsAreEightAsciiDigitsPreservingLeadingZeroes() {
        assertTrue(InputRules.validPublicId("00123456"))
        assertTrue(InputRules.validPublicId("",true))
        listOf("","1234567","123456789","1234 678","１２３４５６７８","١٢٣٤٥٦٧٨","1234567a"," 12345678").forEach {
            assertFalse(it,InputRules.validPublicId(it))
        }
    }
    @Test fun messageBoundariesAndPasswords() {
        assertFalse(InputRules.validMessage("  "))
        assertTrue(InputRules.validMessage("Сәлем! Как дела?"))
        assertTrue(InputRules.validMessage("a".repeat(4000)))
        assertFalse(InputRules.validMessage("a".repeat(4001)))
        assertFalse(InputRules.validPassword("1234567"))
        assertTrue(InputRules.validPassword("Long-password"))
    }
    @Test fun analyzerSupportsThreeLanguages() {
        assertEquals(Category.Environment,TaskAnalyzer.analyze("Убрать мусор в парке").category)
        assertEquals(Category.Environment,TaskAnalyzer.analyze("Саябақта қоқыс жинау").category)
        assertEquals(Category.Education,TaskAnalyzer.analyze("Teach English").category)
        assertEquals(Category.Essentials,TaskAnalyzer.analyze("Купить продукты").category)
    }
}
